

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a href="<?php echo e(url('user/daftar_barang?jurusan='.$jurusan)); ?>" class="btn btn-primary btn-sm">Peralatan Laboratorium</a>&nbsp;
              <a href="<?php echo e(url('user/daftar_barangmedis?jurusan='.$jurusan)); ?>" class="btn btn-outline-primary btn-sm">Peralatan Medis</a>&nbsp;
              <a href="<?php echo e(url('user/daftar_barangbhp?jurusan='.$jurusan)); ?>" class="btn btn-outline-primary btn-sm">Bahan BHP</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">PERALATAN LABORATORIUM - JURUSAN <?php echo e(strtoupper($jurusan)); ?></h5><hr>

            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Nama Alat</th>
                        <th>Tgl Masuk</th>
                        <th>Merk</th>
                        <th>Type</th>
                        <th>No Seri</th>
                        <th>Kode Barang</th>
                        <th>Ruang</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($a->nama_barang); ?></td>
                        <td><?php echo e($a->tgl_masuk); ?></td>
                        <td><?php echo e($a->merk); ?></td>
                        <td><?php echo e($a->type); ?></td>
                        <td><?php echo e($a->no_seri); ?></td>
                        <td><?php echo e($a->kode_barang); ?></td>
                        <td><?php echo e($a->ruang); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/user/barang.blade.php ENDPATH**/ ?>