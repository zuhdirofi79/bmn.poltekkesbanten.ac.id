

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Ketersediaan Stok Barang</h5>

            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="30">No</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Kategori</th>
                        <th>Stok Tersedia</th>
                        <th>Dipinjam</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->kode_barang); ?></td>
                    <td><?php echo e($a->nama_barang); ?></td>
                    <td><?php echo e($a->kategori); ?></td>
                    <td><?php echo e($a->baik - $a->stok_pinjaman); ?></td>
                    <td>
                      <?php if($a->kategori=='Perlengkapan Sekali Pakai'): ?>
                      -
                      <?php else: ?>
                      <a href="<?php echo e(url('petugas/detail_pinjaman/'.$a->kode_barang)); ?>" target="_blank"><?php echo e($a->stok_pinjaman); ?></a>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </tbody>
            </table>

          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/ketersediaan.blade.php ENDPATH**/ ?>