<?php 
  $notif = DB::select("select * from pinjaman_pengembalian where status='Menunggu Konfirmasi'");
?>
    <aside class="left-sidebar">
      <!-- Sidebar scroll-->
      <div>
        <div class="brand-logo d-flex align-items-center justify-content-between">
          <a href="./index.html" class="text-nowrap logo-img">
            <img src="<?php echo e(asset('img')); ?>/fav.png" height="35" alt="" />&nbsp;&nbsp;&nbsp;<strong>POLKES BANTEN</strong>
          </a>
          <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
            <i class="ti ti-x fs-8"></i>
          </div>
        </div>
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav scroll-sidebar" data-simplebar="">
          <ul id="sidebarnav">

            <?php if( auth()->user()->hasRole('admin') ): ?>
            <li class="nav-small-cap">
              <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
              <span class="hide-menu">Admin</span>
            </li>
            <li class="sidebar-item <?php echo e((request()->segment(2) == 'users')? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('admin/users')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-users"></i>
                </span>
                <span class="hide-menu">Users</span>
              </a>
            </li>

            <li class="sidebar-item <?php echo e((request()->segment(2) == 'user_manage' or request()->segment(2) == 'user_edit')? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('admin/user_manage')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-user-search"></i>
                </span>
                <span class="hide-menu">Manage User</span>
              </a>
            </li>

            <li class="sidebar-item <?php echo e(request()->segment(2) == 'master_data'? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('admin/master_data')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-database"></i>
                </span>
                <span class="hide-menu">Master Data</span>
              </a>
            </li>
            <?php endif; ?>

            <?php if( auth()->user()->hasRole('petugas lab') ): ?>
            <li class="nav-small-cap">
              <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
              <span class="hide-menu">Petugas Lab</span>
            </li>
            <li class="sidebar-item <?php echo e((request()->segment(2) == 'petugas' or request()->segment(3) == 'daftar_barang')? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('petugas/daftar_barang')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-report-medical"></i>
                </span>
                <span class="hide-menu">Daftar Barang</span>
              </a>
            </li>

            <li class="sidebar-item <?php echo e((request()->segment(3) == 'ketersediaan')? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('petugas/ketersediaan')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-3d-rotate"></i>
                </span>
                <span class="hide-menu">Ketersediaan Barang</span>
              </a>
            </li>

            <li class="sidebar-item <?php echo e((request()->segment(3) == 'peminjaman')? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('petugas/peminjaman')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-arrows-left-right"></i>
                </span>
                <span class="hide-menu">Pinjaman & Pengembalian</span>
              </a>
            </li>

            <li class="sidebar-item <?php echo e((request()->segment(3) == 'request')? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('petugas/request')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-checkup-list"></i>
                </span>
                <span class="hide-menu">Request Peminjaman</span>
                <?php if($notif): ?>
                <span class="badge bg-danger rounded-3 fw-semibold"><small><?php echo e(count($notif)); ?></small></span>
                <?php endif; ?>
              </a>
            </li>

            <!-- <li class="sidebar-item <?php echo e((request()->segment(3) == 'barang_masuk')? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('petugas/barang_masuk')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-stack-push"></i>
                </span>
                <span class="hide-menu">Barang Masuk</span>
              </a>
            </li> -->


            <li class="sidebar-item <?php echo e((request()->segment(3) == 'barang_masuk')? 'selected':''); ?>"> 
                <a class="sidebar-link" data-toggle="collapse" href="#submenu1" aria-expanded="false">
                  <span>
                    <i class="ti ti-stack-push"></i>
                  </span>
                <span class="hide-menu">Barang Masuk</span> 
                </a>
                
                <div id="submenu1" class="collapse">
                    <ul class="nav flex-column pl-3">
                        <li class="nav-item">
                            <a class="sidebar-link sidebar-item" href="<?php echo e(url('petugas/barang_masuk/keperawatan')); ?>">
                              <span></span>
                              <span>
                                <i class="ti ti-player-record"></i>
                              </span>
                              <span class="hide-menu">Keperawatan</span> 
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="sidebar-link" href="<?php echo e(url('petugas/kebidanan')); ?>">
                              <span></span>
                              <span>
                                <i class="ti ti-player-record"></i>
                              </span>
                              <span class="hide-menu">Kebidanan</span> 
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="sidebar-link" href="<?php echo e(url('petugas/tlm')); ?>">
                              <span></span>
                              <span>
                                <i class="ti ti-player-record"></i>
                              </span>
                              <span class="hide-menu">TLM</span> 
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="sidebar-item">
              <a class="sidebar-link" href="<?php echo e(url('petugas/laporan_pinjaman')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-file-lambda"></i>
                </span>
                <span class="hide-menu">Laporan Pinjaman</span>
              </a>
            </li>

            <li class="sidebar-item">
              <a class="sidebar-link" href="<?php echo e(url('petugas/laporan_barang_masuk')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-file-lambda"></i>
                </span>
                <span class="hide-menu">Laporan Barang Masuk</span>
              </a>
            </li>

            <li class="sidebar-item">
              <a class="sidebar-link" href="<?php echo e(url('petugas/laporan_pengunjung_lab')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-file-lambda"></i>
                </span>
                <span class="hide-menu">Laporan Pengunjung Lab</span>
              </a>
            </li>
            <?php endif; ?>

            <?php if( auth()->user()->hasRole('mahasiswa') or auth()->user()->hasRole('dosen') ): ?>
            <li class="nav-small-cap">
              <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
              <span class="hide-menu">User</span>
            </li>
            <li class="sidebar-item <?php echo e((request()->segment(2) == 'user' and request()->segment(3) == 'daftar_barang')? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('user/daftar_barang')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-report-medical"></i>
                </span>
                <span class="hide-menu">Daftar Barang</span>
              </a>
            </li>

            <li class="sidebar-item <?php echo e((request()->segment(3) == 'history')? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('user/history')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-history"></i>
                </span>
                <span class="hide-menu">Riwayat Peminjaman</span>
              </a>
            </li>

            <li class="sidebar-item <?php echo e((request()->segment(3) == 'kunjungan')? 'selected':''); ?>">
              <a class="sidebar-link" href="<?php echo e(url('user/kunjungan')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-vaccine"></i>
                </span>
                <span class="hide-menu">Kunjungan Lab</span>
              </a>
            </li>
            <?php endif; ?>

            <?php if( auth()->user()->hasRole('pimpinan') ): ?>
            <li class="nav-small-cap">
              <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
              <span class="hide-menu">Pimpinan</span>
            </li>

            <li class="sidebar-item">
              <a class="sidebar-link" href="<?php echo e(url('petugas/laporan_pinjaman')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-file-lambda"></i>
                </span>
                <span class="hide-menu">Laporan Pinjaman</span>
              </a>
            </li>

            <li class="sidebar-item">
              <a class="sidebar-link" href="<?php echo e(url('petugas/laporan_barang_masuk')); ?>" aria-expanded="false">
                <span>
                  <i class="ti ti-file-lambda"></i>
                </span>
                <span class="hide-menu">Laporan Barang Masuk</span>
              </a>
            </li>
            <?php endif; ?>

          </ul>
        </nav>
        <!-- End Sidebar navigation -->
      </div>
      <!-- End Sidebar scroll-->
    </aside><?php /**PATH D:\xampp\htdocs\polkes\resources\views/layouts/thema_nav.blade.php ENDPATH**/ ?>