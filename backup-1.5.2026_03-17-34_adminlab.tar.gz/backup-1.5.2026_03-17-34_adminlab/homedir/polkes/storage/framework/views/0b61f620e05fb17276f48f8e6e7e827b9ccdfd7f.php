

<?php $__env->startSection('content'); ?>
      <div class="container-fluid col-lg-9">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Peminjmaan Peralatan <?php echo e($ruangan); ?></h5>

            <form action="<?php echo e(url('user/add_peminjaman')); ?>" method="post">
              <?php echo csrf_field(); ?>
                <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">

                  <div class="form-group mb-3 row">
                    <label for="name" class="col-sm-3 col-form-label">Nama</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="name" name="name" value="<?php echo e(auth()->user()->name); ?>" readonly>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="jenis" class="col-sm-3 col-form-label">Jenis Alat</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="jenis" name="jenis" value="<?php echo e($jenis); ?>" readonly>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="ruangan" class="col-sm-3 col-form-label">Ruang Lab</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="ruangan" name="ruangan" value="<?php echo e($ruangan); ?>" readonly>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="penanggung_jawab" class="col-sm-3 col-form-label">Penanggung Jawab</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="penanggung_jawab" name="penanggung_jawab" required>
                    </div>
                  </div>

                  
                  <div class="form-group mb-3 row">
                    <label for="tingkat" class="col-sm-3 col-form-label">Tingkat</label>
                    <div class="col-sm-9">
                      <select id="tingkat" name="tingkat" class="form-control" required>
                        <option value=""></option>
                        <?php $__currentLoopData = $tingkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($d->tingkat); ?>"><?php echo e($d->tingkat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="tgl_peminjaman" class="col-sm-3 col-form-label">Tgl Peminjaman</label>
                    <div class="col-sm-9">
                      <input type="date" class="form-control" id="tgl_peminjaman" name="tgl_peminjaman" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="tgl_pengembalian" class="col-sm-3 col-form-label">Tgl Pengembalian</label>
                    <div class="col-sm-9">
                      <input type="date" class="form-control" id="tgl_pengembalian" name="tgl_pengembalian" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="waktu_mulai" class="col-sm-3 col-form-label">Waktu Mulai</label>
                    <div class="col-sm-9">
                      <input type="time" class="form-control" id="waktu_mulai" name="waktu_mulai" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="waktu_selesai" class="col-sm-3 col-form-label">Waktu Selesai</label>
                    <div class="col-sm-9">
                      <input type="time" class="form-control" id="waktu_selesai" name="waktu_selesai" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="tujuan" class="col-sm-3 col-form-label">Tujuan</label>
                    <div class="col-sm-9">
                      <select id="tujuan" name="tujuan" class="form-control" required>
                          <option>--Pilih--</option>
                          <option value="Praktikum">Praktikum</option>
                          <option value="Penelitian Dosen">Penelitian Dosen</option>
                          <option value="Penelitian Mahasiswa">Penelitian Mahasiswa</option>
                          <option value="Uji Fungsi">Uji Fungsi</option>
                          <option value="Kalibrasi">Kalibrasi</option>
                          <option value="Lainnya">Lainnya</option>
                      </select>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label class="col-sm-3 col-form-label">Alat/Bahan (boleh pilih lebih dari 1)</label>
                    <div class="col-sm-9 form-check">
                      <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <input type="checkbox" name="barang_id[]" value="<?php echo e($f->id); ?>" class="form-check-input" id="exampleCheck<?php echo e($f->id); ?>">
                      <label class="form-check-label" for="exampleCheck<?php echo e($f->id); ?>"><?php echo e($f->nama); ?></label><br>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>

                <div class="modal-footer">
                  <!-- <button type="submit" class="btn btn-primary">Next</button> -->
                  <a href="" class="btn btn-primary" data-toggle="modal" data-target="#ModalKonfirmasi">Next</a>
                </div>

                <!-- Modal konfirmasi-->
                  <div class="modal fade" id="ModalKonfirmasi" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Persetujuan</h5>
                          <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                        </div>
                        <div class="modal-body">
                         <p>Peringatan Peminjaman Alat Laboratorium</p>
                         <p style="text-align: justify;">Dengan ini saya <?php echo e(auth()->user()->name); ?>, menyatakan bahwa saya telah membaca, memahami, dan menerima semua aturan dan ketentuan yang berlaku terkait dengan peminjaman alat laboratorium pada <?php echo e(ENV('APP_NAME')); ?>. Saya bersedia mentaati setiap aturan yang telah ditetapkan dan bertanggung jawab atas alat-alat yang dipinjamkan kepada saya.</p>
                         <p style="text-align: justify;">Saya memahami bahwa setiap kerusakan atau kehilangan yang terjadi selama masa peminjaman akan menjadi tanggung jawab saya. Saya siap untuk mengganti biaya perbaikan atau mengganti alat yang hilang sesuai dengan ketentuan yang berlaku.</p>
                         <p style="text-align: justify;">Dengan ini, saya menyatakan bahwa saya bertanggung jawab sepenuhnya atas peminjaman alat laboratorium ini dan siap menerima konsekuensi yang timbul apabila melanggar aturan yang telah ditetapkan.</p>
                         <p>Pernyataan ini bersifat mengikat dan sah setelah diberikan konfirmasi.</p>

                         <input type="checkbox" name="setuju" required class="form-check-input" id="setuju">
                         <label class="form-check-label" for="setuju">Saya faham, dan saya mengerti.</label>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-danger">Ajukan Pinjaman</button>
                        </div>
                      </div>
                    </div>
                  </div>

              </form>

          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema_select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/user/req_peminjaman.blade.php ENDPATH**/ ?>