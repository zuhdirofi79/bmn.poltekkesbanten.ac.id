

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a href="<?php echo e(url('user/daftar_barang?jurusan='.$jurusan)); ?>" class="btn btn-outline-primary btn-sm">Peralatan Laboratorium</a>&nbsp;
              <a href="<?php echo e(url('user/daftar_barangmedis?jurusan='.$jurusan)); ?>" class="btn btn-primary btn-sm">Peralatan Medis</a>&nbsp;
              <a href="<?php echo e(url('user/daftar_barangbhp?jurusan='.$jurusan)); ?>" class="btn btn-outline-primary btn-sm">Bahan BHP</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">PERALATAN MEDIS - JURUSAN <?php echo e(strtoupper($jurusan)); ?></h5><hr>

            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Nama</th>
                        <th>Stok</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $bhp_alat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <td><?php echo e($a->stok); ?></td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/user/barangmedis.blade.php ENDPATH**/ ?>