

<?php $__env->startSection('content'); ?>
      <div class="container-fluid col-lg-9">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">EDIT BAHAN BHP</h5>
            <form action="<?php echo e(url('petugas/edit_bhp_bahan')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
            <input type="hidden" name="jurusan" value="<?php echo e($data->jurusan); ?>">

            <div class="form-group mb-3 row">
              <label for="nama" class="col-sm-3 col-form-label">Nama</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($data->nama); ?>" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="kimia" class="col-sm-3 col-form-label">Kimia</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="kimia" name="kimia" value="<?php echo e($data->kimia); ?>">
              </div>
            </div>
                          
            <div class="form-group mb-3 row">
                <label for="satuan" class="col-sm-3 col-form-label">Satuan</label>
                <div class="col-sm-9">
                  <select id="satuan" name="satuan" class="form-control" required>
                      <option value="gram" <?php echo e(($data->satuan=='gram')?'selected':''); ?>>gram</option>
                      <option value="mg" <?php echo e(($data->satuan=='mg')?'selected':''); ?>>mg</option>
                      <option value="liter" <?php echo e(($data->satuan=='liter')?'selected':''); ?>>liter</option>
                      <option value="ml" <?php echo e(($data->satuan=='ml')?'selected':''); ?>>ml</option>
                      <option value="box" <?php echo e(($data->satuan=='box')?'selected':''); ?>>box</option>
                      <option value="pcs" <?php echo e(($data->satuan=='pcs')?'selected':''); ?>>pcs</option>
                      <option value="pack" <?php echo e(($data->satuan=='pack')?'selected':''); ?>>pack</option>
                      <option value="botol" <?php echo e(($data->satuan=='botol')?'selected':''); ?>>botol</option>
                  </select>
                </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="tgl_expired" class="col-sm-3 col-form-label">Tgl Expired</label>
              <div class="col-sm-9">
                <input type="date" class="form-control" id="tgl_expired" name="tgl_expired" value="<?php echo e($data->tgl_expired); ?>" required>
              </div>
            </div>


            <div style="float: right;">
              <a href="<?php echo e(url('petugas/barangbhp?jurusan='.$data->jurusan)); ?>" class="btn btn-secondary">Back</a>
              <button type="submit" class="btn btn-primary">Edit</button>
            </div>

            </form>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adminlab/polkes/resources/views/petugas_lab/edit_bhp.blade.php ENDPATH**/ ?>