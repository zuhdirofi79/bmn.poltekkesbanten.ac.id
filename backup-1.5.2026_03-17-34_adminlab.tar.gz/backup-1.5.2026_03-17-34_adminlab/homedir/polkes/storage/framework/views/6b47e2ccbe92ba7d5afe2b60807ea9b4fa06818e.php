<?php echo e($slot); ?>

<?php /**PATH /home/adminlab/polkes/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>