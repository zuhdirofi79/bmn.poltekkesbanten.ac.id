

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#exampleModal">Tambah Data</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">Daftar Barang</h5>

            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="30">No</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Kategori</th>
                        <th>Stok</th>
                        <th>Baik</th>
                        <th>Rusak</th>
                        <th>Status</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($a->kode_barang); ?></td>
                        <td><?php echo e($a->nama_barang); ?></td>
                        <td><?php echo e($a->kategori); ?></td>
                        <td><?php echo e($a->stok); ?></td>
                        <td><?php echo e($a->baik); ?></td>
                        <td><?php echo e($a->rusak); ?></td>
                        <td>
                            <?php if($a->status=='active'): ?> 
                            <span class="badge bg-success rounded-3 fw-semibold"><small><?php echo e($a->status); ?></small></span>
                            <?php else: ?>
                            <span class="badge bg-danger rounded-3 fw-semibold"><small><?php echo e($a->status); ?></small></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#ModalEdit<?php echo e($a->id); ?>"><span><i class="ti ti-edit fs-4"></i></span></button>
                            <!-- <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#ModalDelete<?php echo e($a->id); ?>"><span><i class="ti ti-trash fs-4"></i></span></button> -->
                        </td>
                    </tr>


                    <!-- Modal edit barang-->
                    <div class="modal fade" id="ModalEdit<?php echo e($a->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                        <form action="<?php echo e(url('petugas/edit_barang')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                          </div>
                          <div class="modal-body">

                            <div class="form-group mb-3 row">
                              <label for="kode_barang" class="col-sm-3 col-form-label">Kode Barang</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="kode_barang" name="kode_barang" value="<?php echo e($a->kode_barang); ?>" disabled>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="nama_barang" class="col-sm-3 col-form-label">Nama Barang</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="nama_barang" name="nama_barang" value="<?php echo e($a->nama_barang); ?>" required>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="kategori" class="col-sm-3 col-form-label">Kategori</label>
                              <div class="col-sm-9">
                                <select id="kategori" name="kategori" class="form-control" required>
                                  <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($a->kategori==$b->kategori): ?>
                                      <option value="<?php echo e($b->kategori); ?>" selected><?php echo e($b->kode); ?> - <?php echo e($b->kategori); ?></option>
                                      <?php else: ?>
                                      <option value="<?php echo e($b->kategori); ?>"><?php echo e($b->kode); ?> - <?php echo e($b->kategori); ?></option>
                                      <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="stok" class="col-sm-3 col-form-label">Stok</label>
                              <div class="col-sm-9">
                                <input type="number" class="form-control" id="stok" name="stok" value="<?php echo e($a->stok); ?>" required>
                              </div>
                            </div>

                            
                            <div class="form-group mb-3 row">
                              <label for="baik" class="col-sm-3 col-form-label">Baik</label>
                              <div class="col-sm-9">
                                <input type="number" class="form-control" id="baik" name="baik" value="<?php echo e($a->baik); ?>" required>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="rusak" class="col-sm-3 col-form-label">Rusak</label>
                              <div class="col-sm-9">
                                <input type="number" class="form-control" id="rusak" name="rusak" value="<?php echo e($a->rusak); ?>" required>
                              </div>
                            </div>
                            

                            <div class="form-group mb-3 row">
                              <label for="status" class="col-sm-3 col-form-label">Status</label>
                              <div class="col-sm-9">
                                <select id="status" name="status" class="form-control" required>
                                  <option value="active" <?php echo e(($a->status=='active')?'selected':''); ?>>active</option>
                                  <option value="disable" <?php echo e(($a->status=='disable')?'selected':''); ?>>disable</option>
                                </select>
                              </div>
                            </div>

                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Edit</button>
                          </div>
                        </form>
                        </div>
                      </div>
                    </div>

                    <!-- Modal edit barang-->
                    <div class="modal fade" id="ModalDelete<?php echo e($a->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                        <form action="<?php echo e(url('petugas/delete_barang')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                          </div>
                          <div class="modal-body">

                            <p>Apakah anda yakin ingin menghapus data <b><?php echo e($a->kode_barang); ?> - <?php echo e($a->nama_barang); ?></b> ?</p>

                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger">Delete</button>
                          </div>
                        </form>
                        </div>
                      </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

          </div>
        </div>
      </div>


    <!-- Modal add barang-->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('petugas/add_barang')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="kode_barang" class="col-sm-3 col-form-label">Kode Barang</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="kode_barang" name="kode_barang" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="nama_barang" class="col-sm-3 col-form-label">Nama Barang</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="kategori" class="col-sm-3 col-form-label">Kategori</label>
              <div class="col-sm-9">
                <select id="kategori" name="kategori" class="form-control" required>
                  <option>--Pilih--</option>
                  <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($b->kategori); ?>"><?php echo e($b->kode); ?> - <?php echo e($b->kategori); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="stok" class="col-sm-3 col-form-label">Stok</label>
              <div class="col-sm-9">
                <input type="number" class="form-control" id="stok" name="stok"required>
              </div>
            </div>

            <!-- <div class="form-group mb-3 row">
              <label for="baik" class="col-sm-3 col-form-label">Baik</label>
              <div class="col-sm-9">
                <input type="number" class="form-control" id="baik" name="baik" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="rusak" class="col-sm-3 col-form-label">Rusak</label>
              <div class="col-sm-9">
                <input type="number" class="form-control" id="rusak" name="rusak" required>
              </div>
            </div> -->

            <div class="form-group mb-3 row">
              <label for="status" class="col-sm-3 col-form-label">Status</label>
              <div class="col-sm-9">
                <select id="status" name="status" class="form-control" required>
                  <option value="active" selected>active</option>
                  <option value="disable">disable</option>
                </select>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add</button>
          </div>
        </form>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\polkes\resources\views/petugas_lab/daftar_barang.blade.php ENDPATH**/ ?>