

<?php $__env->startSection('content'); ?>

    <div class="col-lg-6">
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#exampleModalKategori">Tambah Kategori</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">Kategori Barang</h5>
            <table id="myTable2" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Kategori</th>
                        <th>Status</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($a->kode); ?></td>
                        <td><?php echo e($a->kategori); ?></td>
                        <td>
                            <?php if($a->status=='active'): ?> 
                            <span class="badge bg-success rounded-3 fw-semibold"><small><?php echo e($a->status); ?></small></span>
                            <?php else: ?>
                            <span class="badge bg-danger rounded-3 fw-semibold"><small><?php echo e($a->status); ?></small></span>
                            <?php endif; ?>
                        </td>
                        <td><a href="" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModalKategori<?php echo e($a->id); ?>"><span><i class="ti ti-edit"></i></span></a></td>
                    </tr>

                    <!-- Modal add kategori-->
                    <div class="modal fade" id="exampleModalKategori<?php echo e($a->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                        <form action="<?php echo e(url('admin/edit_kategori')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Edit Data Kategori</h5>
                            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                          </div>
                          <div class="modal-body">

                            <div class="form-group mb-3 row">
                              <label for="kode" class="col-sm-3 col-form-label">Kode Kategori*</label>
                              <div class="col-sm-9">
                                <select id="kode" name="kode" class="form-control" required>
                                  <?php $__currentLoopData = $abjad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($a->kode==$b->abjad): ?>
                                  <option value="<?php echo e($b->abjad); ?>" selected><?php echo e($b->abjad); ?></option>
                                  <?php else: ?>
                                  <option value="<?php echo e($b->abjad); ?>"><?php echo e($b->abjad); ?></option>
                                  <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="kategori" class="col-sm-3 col-form-label">Nama Kategori*</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="kategori" name="kategori" value="<?php echo e($a->kategori); ?>" required>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="status" class="col-sm-3 col-form-label">Status</label>
                              <div class="col-sm-9">
                                <select id="status" name="status" class="form-control" required>
                                  <option value="active" <?php echo e(($a->status=='active')?'selected':''); ?>>active</option>
                                  <option value="disable" <?php echo e(($a->status=='disable')?'selected':''); ?>>disable</option>
                                </select>
                              </div>
                            </div>

                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update</button>
                          </div>
                        </form>
                        </div>
                      </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>


    <!-- Modal add supplier-->
    <div class="modal fade" id="exampleModalSupplier" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('admin/add_supplier')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Data Supplier</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="nama_supplier" class="col-sm-3 col-form-label">Nama Supplier*</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="nama_supplier" name="nama_supplier" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="email" class="col-sm-3 col-form-label">Email</label>
              <div class="col-sm-9">
                <input type="email" class="form-control" id="email" name="email">
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="telepon" class="col-sm-3 col-form-label">Telepon</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="telepon" name="telepon" oninput="this.value = this.value.replace(/[^0-9]/g, '').substring(0, 13)">
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="alamat" class="col-sm-3 col-form-label">Alamat</label>
              <div class="col-sm-9">
                <textarea class="form-control" id="alamat" name="alamat"></textarea>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="status" class="col-sm-3 col-form-label">Status</label>
              <div class="col-sm-9">
                <select id="status" name="status" class="form-control" required>
                  <option value="active" selected>active</option>
                  <option value="disable">disable</option>
                </select>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add</button>
          </div>
        </form>
        </div>
      </div>
    </div>


    <!-- Modal add kategori-->
    <div class="modal fade" id="exampleModalKategori" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('admin/add_kategori')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Data Kategori</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="kode" class="col-sm-3 col-form-label">Kode Kategori*</label>
              <div class="col-sm-9">
                <select id="kode" name="kode" class="form-control" required>
                  <option>-- Pilih --</option>
                  <?php $__currentLoopData = $abjad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($b->abjad); ?>"><?php echo e($b->abjad); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="kategori" class="col-sm-3 col-form-label">Nama Kategori*</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="kategori" name="kategori" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="status" class="col-sm-3 col-form-label">Status</label>
              <div class="col-sm-9">
                <select id="status" name="status" class="form-control" required>
                  <option value="active" selected>active</option>
                  <option value="disable">disable</option>
                </select>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add</button>
          </div>
        </form>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\polkes\resources\views/admin/master_data.blade.php ENDPATH**/ ?>