

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#exampleModal">Request Peminjaman Barang</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">Daftar Barang</h5>

            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="30">No</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Kategori</th>
                        <th>Stok Tersedia</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->kode_barang); ?></td>
                    <td><?php echo e($a->nama_barang); ?></td>
                    <td><?php echo e($a->kategori); ?></td>
                    <td><?php echo e($a->baik - $a->stok_pinjaman); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </tbody>
            </table>

          </div>
        </div>
      </div>


      <!-- Modal add request-->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('user/add_request')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Form Request Pinjaman Barang</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="username" class="col-sm-3 col-form-label">NIM/NID</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="username" name="username" required readonly value="<?php echo e(Auth()->user()->username); ?>">
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="name" class="col-sm-3 col-form-label">Nama</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="name" name="name" required readonly value="<?php echo e(Auth()->user()->name); ?>">
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="kode_barang" class="col-sm-3 col-form-label">Ingin Meminjam</label>
              <div class="col-sm-9">
                <select id="kode_barang" name="kode_barang" class="form-control" required>
                  <option>-- Pilih --</option>
                  <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($b->kode_barang); ?>"><?php echo e($b->kode_barang); ?> - <?php echo e($b->nama_barang); ?>, 
                    stok=<?php echo e($b->baik - $b->stok_pinjaman); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="stok_pinjaman" class="col-sm-3 col-form-label">Sejumlah</label>
              <div class="col-sm-9">
                <input type="number" class="form-control" id="stok_pinjaman" name="stok_pinjaman" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="keperluan" class="col-sm-3 col-form-label">Untuk Keperluan</label>
              <div class="col-sm-9">
                <textarea class="form-control" id="keperluan" name="keperluan" required></textarea>
              </div>
            </div>

            

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add</button>
          </div>
        </form>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/user/daftar_barang.blade.php ENDPATH**/ ?>