

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('petugas_lab.lap_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-lg-9">
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Laporan Penambahan Peralatan Medis</h5>

           <form action="<?php echo e(url('petugas/laporan/penambahan_alat_medis')); ?>" method="get">  
              <div style="" class="d-flex justify-content-center">
                <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
                <input type="date" class="form-control" id="tgl_awal" name="tgl_awal" style="width:250px;" required value="<?php echo e($tgl_awal); ?>">
                 &nbsp; &nbsp; Sampai Dengan &nbsp; &nbsp;
                <input type="date" class="form-control" id="tgl_akhir" name="tgl_akhir" style="width:250px;" required value="<?php echo e($tgl_akhir); ?>">
                 &nbsp;
                <button type="submit" class="btn btn-outline-primary">Submit</button>
              </div>
            </form>
            <br>

            <?php if($data): ?>
            <table id="exampleButton" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Tgl Input</th>
                        <th>Nama Barang</th>
                        <th>Stok Penambahan</th>
                        <th>Petugas</th>
                        <th>Catatan</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e(substr($a->created_at,0,10)); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <td><?php echo e($a->stok); ?> <?php echo e($a->satuan); ?></td>
                    <td><?php echo e($a->petugas); ?></td>
                    <td><?php echo e($a->keterangan); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>

          </div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/urbx6991/polkes/resources/views/petugas_lab/lap_penambahan_alat_medis.blade.php ENDPATH**/ ?>