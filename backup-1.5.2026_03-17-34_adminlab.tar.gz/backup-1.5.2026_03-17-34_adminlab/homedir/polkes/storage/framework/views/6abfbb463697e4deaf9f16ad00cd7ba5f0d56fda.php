

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#ModalForm">Formulir Peminjaman Alat</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">Peminjaman Peralatan</h5>
            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="30">No</th>
                        <th>Jenis Alat</th>
                        <th>Ruang Lab</th>
                        <th>Penanggung Jawab</th>
                        <th>Tingkat</th>
                        <th>Tgl Permintaan</th>
                        <th>Status</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->jenis); ?></td>
                    <td><?php echo e($a->ruangan); ?></td>
                    <td><?php echo e($a->penanggung_jawab); ?></td>
                    <td><?php echo e($a->tingkat); ?></td>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    <td><?php echo e($a->status); ?></td>
                    <td><a href="<?php echo e(url('user/peminjaman_detail/'.$a->id)); ?>" target="_blank" class="btn btn-outline-primary btn-sm">Detail</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>


    <!-- Modal add barang-->
    <div class="modal fade" id="ModalForm" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('user/req_peminjaman')); ?>" method="get">
          <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Formulir Peminjaman Alat</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="jenis" class="col-sm-3 col-form-label">Jenis Alat</label>
              <div class="col-sm-9">
                <select id="jenis" name="jenis" class="form-control" required>
                    <option value="">--Pilih--</option>
                    <option value="Peralatan Laboratorium">Peralatan Laboratorium</option>
                    <option value="Peralatan Medis">Peralatan Medis</option>
                    <option value="Bahan BHP">Bahan BHP</option>
                </select>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="ruang" class="col-sm-3 col-form-label">Ruang</label>
              <div class="col-sm-9">
                <select id="ruang" name="ruang" class="form-control" required>
                    <option value="">--Pilih--</option>
                  <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($b->nama_ruang); ?>"><?php echo e($b->kampus); ?> - <?php echo e($b->nama_ruang); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Next</button>
          </div>
        </form>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/user/peminjaman.blade.php ENDPATH**/ ?>