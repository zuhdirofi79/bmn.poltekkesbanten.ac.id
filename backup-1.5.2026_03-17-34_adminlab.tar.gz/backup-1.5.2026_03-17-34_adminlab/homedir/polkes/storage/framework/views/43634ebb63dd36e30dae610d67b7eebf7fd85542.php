

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('petugas_lab.lap_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-lg-9">
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Laporan Peralatan Laboratorium</h5>

            <!-- <form action="<?php echo e(url('petugas/laporan_barang_masuk')); ?>" method="get">  
              <div style="" class="d-flex justify-content-center">
                <input type="date" class="form-control" id="tgl_awal" name="tgl_awal" style="width:250px;" required>
                 &nbsp; &nbsp; Sampai Dengan &nbsp; &nbsp;
                <input type="date" class="form-control" id="tgl_akhir" name="tgl_akhir" style="width:250px;" required>
                 &nbsp;
                <button type="submit" class="btn btn-outline-primary">Submit</button>
              </div>
            </form>
            <br> -->

            <table id="exampleButton" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Nama Alat</th>
                        <th>Tgl Masuk</th>
                        <th>Merk</th>
                        <th>Type</th>
                        <th>No Seri</th>
                        <th>Kode Barang</th>
                        <th>Ruang</th>
                        <th>Stok</th>
                        <th>Kondisi</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <td><?php echo e($a->tgl_masuk); ?></td>
                    <td><?php echo e($a->merk); ?></td>
                    <td><?php echo e($a->type); ?></td>
                    <td><?php echo e($a->no_seri); ?></td>
                    <td><?php echo e($a->kode_barang); ?></td>
                    <td><?php echo e($a->ruang); ?></td>
                    <td><?php echo e($a->stok); ?> <?php echo e($a->satuan); ?></td>
                    <td><?php echo e($a->kondisi); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/urbx6991/polkes/resources/views/petugas_lab/lap_alat_lab.blade.php ENDPATH**/ ?>