

<?php $__env->startSection('content'); ?>
      <div class="container-fluid mt-2">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#exampleModal">+ Tambah Barang Masuk</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">Barang Masuk</h5>

            <?php if($data): ?>
            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tgl Masuk</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Jumlah</th>
                        <th>Petugas</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($a->created_at); ?></td>
                        <td><?php echo e($a->kode_barang); ?></td>
                        <td><?php echo e($a->nama_barang); ?></td>
                        <td><?php echo e($a->stok_masuk); ?></td>
                        <td><?php echo e($a->petugas); ?></td>
                        <td>
                            <a href="" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#editModal<?php echo e($loop->iteration); ?>"><i class="ti ti-edit"></i></a>
                            <a href="" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#deleteModal<?php echo e($loop->iteration); ?>"><i class="ti ti-trash"></i></a>
                        </td>
                    </tr>

                    <!-- Modal edit-->
                    <div class="modal fade" id="editModal<?php echo e($loop->iteration); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <form action="<?php echo e(url('petugas/edit_barang_masuk')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Edit Data</h5>
                            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                          </div>
                          <div class="modal-body">

                            <div class="form-group mb-3 row">
                              <label for="kode_barang" class="col-sm-3 col-form-label">Barang</label>
                              <div class="col-sm-9">
                                <select class="form-control select2" id="kode_barang" name="kode_barang" required>
                                  <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($b->kode_barang); ?>" <?=($a->kode_barang==$b->kode_barang)?'selected':'';?>><?php echo e($b->kode_barang); ?> - <?php echo e($b->nama_barang); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="stok_masuk" class="col-sm-3 col-form-label">Jumlah</label>
                              <div class="col-sm-9">
                                <input type="number" class="form-control" id="stok_masuk" name="stok_masuk" value="<?php echo e($a->stok_masuk); ?>" required>
                              </div>
                            </div>

                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">update</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>

                    <!-- Modal Delete-->
                    <div class="modal fade" id="deleteModal<?php echo e($loop->iteration); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <form action="<?php echo e(url('petugas/delete_barang_masuk')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Delete Data</h5>
                            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                          </div>
                          <div class="modal-body">
                            <p>Apakah anda yakin ingin menghapus data ini <b><?php echo e($a->kode_barang); ?> - <?php echo e($a->nama_barang); ?></b>?</p>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger">Delete</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <br>
            <div class="float-right">
              <a href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#updatestokgudangModal">Update Stok Gudang</a>
            </div>
            <br>
            <?php endif; ?>

          </div>
        </div>
      </div>


    <!-- Modal add barang masuk-->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('petugas/add_barang_masuk')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Data Barang Masuk</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="kode_barang" class="col-sm-3 col-form-label">Barang</label>
              <div class="col-sm-9">
                <select id="kode_barang" name="kode_barang" class="form-control" required>
                  <option>-- Pilih --</option>
                  <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($b->kode_barang); ?>"><?php echo e($b->kode_barang); ?> - <?php echo e($b->nama_barang); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>


            <div class="form-group mb-3 row">
              <label for="stok_masuk" class="col-sm-3 col-form-label">Jumlah</label>
              <div class="col-sm-9">
                <input type="number" class="form-control" id="stok_masuk" name="stok_masuk" required>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add</button>
          </div>
        </form>
        </div>
      </div>
    </div>


    <!-- Modal update stok gudang-->
  <div class="modal fade" id="updatestokgudangModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="<?php echo e(url('petugas/update_barang_masuk')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <input type="hidden" name="id[]" value="<?php echo e($a->id); ?>">
          <input type="hidden" name="kode_barang[]" value="<?php echo e($a->kode_barang); ?>">
          <input type="hidden" name="stok_masuk[]" value="<?php echo e($a->stok_masuk); ?>">
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <input type="hidden" name="jumlah_data" value="<?php echo e(count($data)); ?>">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Update Stok Barang</h5>
          <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
        </div>
        <div class="modal-body">

          <div class="alert alert-warning alert-dismissible">
            <h5><i class="icon fas fa-exclamation-triangle"></i> Perhatikan baik-baik!</h5>
            Periksa kembali stok barang masuk sebelum diupdate dengan stok barang saat ini, pastikan semua data sudah bener. <br><br>
            Proses update akan secara otomatis menambahkan data stok saat ini dengan jumlah barang masuk, apabila sudah diupdate maka tidak dapat dirubah kembali! <br><br> Apakah anda sudah yakin data diatas sudah benar?
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/barang_masuk.blade.php ENDPATH**/ ?>