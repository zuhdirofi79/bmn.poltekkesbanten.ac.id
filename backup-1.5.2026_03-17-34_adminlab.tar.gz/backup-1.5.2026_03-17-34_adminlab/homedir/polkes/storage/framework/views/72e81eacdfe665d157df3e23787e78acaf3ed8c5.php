

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#exampleModal">Input Form Kunjungan Lab</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">History Kunjungan Lab</h5>
            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="30">No</th>
                        <th>Tgl Kunjugan</th>
                        <th>Waktu Mulai</th>
                        <th>Waktu Selesai</th>
                        <th>Ruang Lab</th>
                        <th>Tujuan</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->tgl_kunjungan); ?></td>
                    <td><?php echo e(substr($a->waktu_mulai,0,5)); ?></td>
                    <td><?php echo e(substr($a->waktu_selesai,0,5)); ?></td>
                    <td><?php echo e($a->ruang_lab); ?></td>
                    <td><?php echo e($a->tujuan); ?></td>
                    <td><?php echo e($a->keterangan); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>

    <?php $date = date('Y-m-d'); ?>
    <!-- Modal add barang-->
    <div class="modal fade" id="exampleModal" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('user/add_kunjungan')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Formulir Kunjugan Lab</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="tgl_kunjungan" class="col-sm-3 col-form-label">Tgl Berkunjung</label>
              <div class="col-sm-9">
                <input type="date" class="form-control" id="tgl_kunjungan" name="tgl_kunjungan" value="<?php echo e($date); ?>" readonly required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="waktu_mulai" class="col-sm-3 col-form-label">Waktu Mulai</label>
              <div class="col-sm-9">
                <input type="time" class="form-control" id="waktu_mulai" name="waktu_mulai" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="waktu_selesai" class="col-sm-3 col-form-label">Waktu Selesai</label>
              <div class="col-sm-9">
                <input type="time" class="form-control" id="waktu_selesai" name="waktu_selesai" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="ruang" class="col-sm-3 col-form-label">Ruang</label>
              <div class="col-sm-9">
                <select id="ruang" name="ruang" class="form-control" required>
                    <option>--Pilih--</option>
                  <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($b->nama_ruang); ?>"><?php echo e($b->kampus); ?> - <?php echo e($b->jurusan); ?>, <?php echo e($b->nama_ruang); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="tujuan" class="col-sm-3 col-form-label">Tujuan Berkunjung</label>
              <div class="col-sm-9">
                <select id="tujuan" name="tujuan" class="form-control" required>
                    <option>--Pilih--</option>
                    <option value="Praktikum">Praktikum</option>
                    <option value="Penelitian Dosen">Penelitian Dosen</option>
                    <option value="Penelitian Mahasiswa">Penelitian Mahasiswa</option>
                    <option value="Uji Fungsi">Uji Fungsi</option>
                    <option value="Kalibrasi">Kalibrasi</option>
                    <option value="Lainnya">Lainnya</option>
                </select>
              </div>
            </div>
            
            <div class="form-group mb-3 row">
              <label for="keterangan" class="col-sm-3 col-form-label">Keterangan / saran</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="keterangan" name="keterangan">
                <small>Opsional</small>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add</button>
          </div>
        </form>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/urbx6991/polkes/resources/views/user/kunjungan.blade.php ENDPATH**/ ?>