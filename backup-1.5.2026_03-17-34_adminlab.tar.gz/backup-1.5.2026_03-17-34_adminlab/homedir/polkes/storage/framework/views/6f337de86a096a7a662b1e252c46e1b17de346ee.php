

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#exampleModal"><span><i class="ti ti-plus"></i></span> Data Barang</a> &nbsp;
              <a href="" class="btn btn-outline-primary btn-sm">Kategori Alat</a>&nbsp;
              <a href="" class="btn btn-outline-primary btn-sm">Kategori BHP</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">INVENTARIS ALAT - JURUSAN <?php echo e(strtoupper($jurusan)); ?></h5>

            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Nama Alat</th>
                        <th>Tgl Masuk</th>
                        <th>Merk</th>
                        <th>Type</th>
                        <th>No Seri</th>
                        <th>Kode Barang</th>
                        <th>Ruang</th>
                        <th width="56">Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($a->nama_barang); ?></td>
                        <td><?php echo e($a->tgl_masuk); ?></td>
                        <td><?php echo e($a->merk); ?></td>
                        <td><?php echo e($a->type); ?></td>
                        <td><?php echo e($a->no_seri); ?></td>
                        <td><?php echo e($a->kode_barang); ?></td>
                        <td><?php echo e($a->ruang); ?></td>
                        <td>
                            <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#ModalEdit<?php echo e($a->id); ?>"><span><i class="ti ti-edit fs-4"></i></span></button>
                            <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#ModalDelete<?php echo e($a->id); ?>"><span><i class="ti ti-trash fs-4"></i></span></button>
                        </td>
                    </tr>

                    <!-- Modal edit barang-->
                    <div class="modal fade" id="ModalEdit<?php echo e($a->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                        <form action="<?php echo e(url('petugas/edit_barang')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
                        <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Edit Data Barang</h5>
                            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                          </div>
                          <div class="modal-body">

                            <div class="form-group mb-3 row">
                              <label for="nama_barang" class="col-sm-3 col-form-label">Nama Alat</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="nama_barang" name="nama_barang" value="<?php echo e($a->nama_barang); ?>" required>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="tgl_masuk" class="col-sm-3 col-form-label">Tahun Masuk</label>
                              <div class="col-sm-9">
                                <input type="date" class="form-control" id="tgl_masuk" name="tgl_masuk" value="<?php echo e($a->tgl_masuk); ?>" required>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="merk" class="col-sm-3 col-form-label">Merk</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="merk" name="merk" value="<?php echo e($a->merk); ?>" required>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="type" class="col-sm-3 col-form-label">Type</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="type" name="type" value="<?php echo e($a->type); ?>" required>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="no_seri" class="col-sm-3 col-form-label">No Seri</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="no_seri" name="no_seri" value="<?php echo e($a->no_seri); ?>" required>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="kode_barang" class="col-sm-3 col-form-label">Kode Barang</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="kode_barang" name="kode_barang" value="<?php echo e($a->kode_barang); ?>" required>
                              </div>
                            </div>

                            <div class="form-group mb-3 row">
                              <label for="ruang" class="col-sm-3 col-form-label">Ruang</label>
                              <div class="col-sm-9">
                                <select id="ruang" name="ruang" class="form-control" required>
                                  <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($a->ruang==$b->nama_ruang): ?>
                                    <option value="<?php echo e($b->nama_ruang); ?>" selected><?php echo e($b->kampus); ?> - <?php echo e($b->jurusan); ?>, <?php echo e($b->nama_ruang); ?></option>
                                  <?php else: ?>
                                  <option value="<?php echo e($b->nama_ruang); ?>"><?php echo e($b->kampus); ?> - <?php echo e($b->jurusan); ?>, <?php echo e($b->nama_ruang); ?></option>
                                  <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>

                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Edit</button>
                          </div>
                        </form>
                        </div>
                      </div>
                    </div>

                    <!-- Modal edit barang-->
                    <div class="modal fade" id="ModalDelete<?php echo e($a->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                        <form action="<?php echo e(url('petugas/delete_barang')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
                        <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Hapus data barang</h5>
                            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                          </div>
                          <div class="modal-body">

                            <div class="form-group">
                              <label for="keterangan">Kenapa anda ingin menghapus data ini?</label>
                              <textarea class="form-control" id="keterangan" name="delete" required></textarea>
                            </div>

                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger">Delete</button>
                          </div>
                        </form>
                        </div>
                      </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

          </div>
        </div>
      </div>


    <!-- Modal add barang-->
    <div class="modal fade" id="exampleModal" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('petugas/add_barang')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Data Barang</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="nama_barang" class="col-sm-3 col-form-label">Nama Alat</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" required>
              </div>
            </div>
            
            <div class="form-group mb-3 row">
              <label for="tgl_masuk" class="col-sm-3 col-form-label">Tahun Masuk</label>
              <div class="col-sm-9">
                <input type="date" class="form-control" id="tgl_masuk" name="tgl_masuk" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="merk" class="col-sm-3 col-form-label">Merk</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="merk" name="merk"required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="type" class="col-sm-3 col-form-label">Type</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="type" name="type" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="no_seri" class="col-sm-3 col-form-label">No Seri</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="no_seri" name="no_seri" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="kode_barang" class="col-sm-3 col-form-label">Kode Barang</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="kode_barang" name="kode_barang" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="ruang" class="col-sm-3 col-form-label">Ruang</label>
              <div class="col-sm-9">
                <select id="ruang" name="ruang" class="form-control" required>
                    <option>--Pilih--</option>
                  <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($b->nama_ruang); ?>"><?php echo e($b->kampus); ?> - <?php echo e($b->jurusan); ?>, <?php echo e($b->nama_ruang); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add</button>
          </div>
        </form>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/barang_kebidanan.blade.php ENDPATH**/ ?>