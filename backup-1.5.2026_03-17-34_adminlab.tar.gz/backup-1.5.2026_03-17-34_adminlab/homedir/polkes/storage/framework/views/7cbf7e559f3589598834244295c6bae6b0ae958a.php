

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Peminjaman & Pengembalian Peralatan Detail <?php echo e($jurusan); ?> testing</h5>
              <input type="hidden" name="peminjaman_id" value="<?php echo e($id); ?>">
            <table class="table table-bordered" style="width:100%">
                <thead style="background-color:#78faed;">
                    <tr>
                        <th width="30">No</th>
                        <th>Jenis</th>
                        <th>Nama Barang</th>
                        <?php if($status->jenis=='Bahan BHP'): ?>
                        <th>Tgl Pemakaian</th>
                        <th>Stok Pemakaian</th>
                        <th>Status</th>
                        <?php else: ?>
                        <th>Tgl Pinjaman</th>
                        <th>Tgl Pengembalian</th>
                        <th>Stok Pinjam</th>
                        <th>Stok Pengembalian</th>
                        <th>Status</th>
                        <th>Kondisi</th>
                        <th></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <form action="<?php echo e(url('petugas/pengembalian_submit2')); ?>" method="post" onsubmit="disableSubmitButton()">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="peminjaman_id" value="<?php echo e($id); ?>">
                  <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                  <input type="hidden" name="barang_id" value="<?php echo e($a->barang_id); ?>">
                  <input type="hidden" name="stok_pinjam" value="<?php echo e($a->stok_pinjam); ?>">
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->jenis); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <?php if($status->jenis=='Bahan BHP'): ?>
                        <td><?php echo e($a->tgl_pinjaman); ?></td>
                        <td><?php echo e($a->stok_pinjam); ?> <?php echo e($a->satuan); ?></td>
                        <td><?php echo e($a->status); ?></td>
                    <?php else: ?>
                        <td><?php echo e($a->tgl_pinjaman); ?></td>
                        <td><?php echo e($a->tgl_pengembalian); ?></td>
                        <td><?php echo e($a->stok_pinjam); ?> <?php echo e($a->satuan); ?></td>
                        <?php if($a->status=='Dipinjamkan'): ?>
                          <td><input class="form-control" name="stok_pengembalian" type="number" name="stok_pengembalian" min="1" max="<?php echo e($a->stok_pinjam); ?>" value="<?php echo e($a->stok_pinjam); ?>" required></td>
                        <?php else: ?>
                        <td><?php echo e($a->stok_pinjam); ?> <?php echo e($a->satuan); ?></td>
                        <?php endif; ?>
                        <td>
                        <?php if($a->status=='Dipinjamkan'): ?>
                          <select id="status" name="status" class="form-control" required>
                            <option value=""><?php echo e($a->status); ?></option>
                            <option value="Dikembalikan">Dikembalikan</option>
                            <option value="Hilang">Hilang</option>
                          </select>
                        <?php else: ?>
                          <?php echo e($a->status); ?>

                        <?php endif; ?>
                        </td>
                        <td>
                        <?php if($a->status=='Dipinjamkan'): ?>
                          <select id="kondisi" name="kondisi" class="form-control" required>
                            <option value=""></option>
                            <option value="Baik">Baik</option>
                            <option value="Rusak">Rusak</option>
                            <option value="Pecah">Pecah</option>
                            <option value="Hilang">Hilang</option>
                          </select>
                        <?php else: ?>
                          <?php echo e($a->kondisi); ?>

                        <?php endif; ?>
                        </td>
                    <?php endif; ?>
                    
                    <?php if($a->status=='Dipinjamkan'): ?>
                    <td>
                        <button class="btn btn-primary btn-sm" type="submit" id="submitButton">Submit</button>
                      </form>
                    </td>
                    <?php endif; ?>

                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
          </div>
        </div>
      </div>

<script>
    function disableSubmitButton() {
        document.getElementById("submitButton").disabled = true;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adminlab/polkes/resources/views/petugas_lab/pengembalian_detail2.blade.php ENDPATH**/ ?>