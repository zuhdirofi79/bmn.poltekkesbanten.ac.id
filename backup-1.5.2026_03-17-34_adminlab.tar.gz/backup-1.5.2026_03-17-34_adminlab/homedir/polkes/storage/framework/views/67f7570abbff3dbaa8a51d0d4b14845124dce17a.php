

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('petugas_lab.lap_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-lg-9">
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Laporan Peminjaman Bahan BHP</h5>

            <form action="<?php echo e(url('petugas/laporan/pinjaman_bahan_bhp')); ?>" method="get">  
              <div style="" class="d-flex justify-content-center">
                <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
                <input type="date" class="form-control" id="tgl_awal" name="tgl_awal" style="width:250px;" required value="<?php echo e($tgl_awal); ?>">
                 &nbsp; &nbsp; Sampai Dengan &nbsp; &nbsp;
                <input type="date" class="form-control" id="tgl_akhir" name="tgl_akhir" style="width:250px;" required value="<?php echo e($tgl_akhir); ?>">
                 &nbsp;
                <button type="submit" class="btn btn-outline-primary">Submit</button>
              </div>
            </form>
            <br>

            <?php if($data): ?>
            <table id="exampleButton" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Nama</th>
                        <th>Ruangan</th>
                        <th>Penganggung Jawab</th>
                        <th>Tingkat</th>
                        <th>Jenis Barang</th>
                        <th>Nama Barang</th>
                        <th>Stok Pinjaman</th>
                        <th>Tgl Pinjaman</th>
                        <th>Tgl Pengembalian</th>
                        <th>Petugas Peminjaman</th>
                        <th>Petugas Pengembalian</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->name); ?></td>
                    <td><?php echo e($a->ruangan); ?></td>
                    <td><?php echo e($a->penanggung_jawab); ?></td>
                    <td><?php echo e($a->tingkat); ?></td>
                    <td><?php echo e($a->jenis); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <td><?php echo e($a->stok_pinjam); ?></td>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    <td><?php echo e($a->tgl_pengembalian); ?></td>
                    <td><?php echo e($a->petugas_peminjaman); ?></td>
                    <td><?php echo e($a->petugas_pengembalian); ?></td>
                    <td><?php echo e($a->status); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>

          </div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/lap_pinjaman_bahan_bhp.blade.php ENDPATH**/ ?>