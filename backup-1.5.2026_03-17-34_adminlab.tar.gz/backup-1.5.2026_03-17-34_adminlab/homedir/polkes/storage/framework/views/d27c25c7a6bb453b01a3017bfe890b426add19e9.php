

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Peminjaman Peralatan Detail</h5>
            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="30">No</th>
                        <th>Jenis</th>
                        <th>Nama Barang</th>
                        <th>Stok</th>
                        <?php if($jenis=='Bahan BHP'): ?>
                        <th>Tgl Pemakaian</th>
                        <?php else: ?>
                        <th>Tgl Pinjaman</th>
                        <th>Tgl Pengembalian</th>
                        <?php endif; ?>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->jenis); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <td><?php echo e($a->stok_pinjam); ?> <?php echo e($a->satuan); ?></td>
                    <?php if($jenis=='Bahan BHP'): ?>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    <?php else: ?>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    <td><?php echo e($a->tgl_pengembalian); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($a->status); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adminlab/polkes/resources/views/user/peminjaman_detail.blade.php ENDPATH**/ ?>