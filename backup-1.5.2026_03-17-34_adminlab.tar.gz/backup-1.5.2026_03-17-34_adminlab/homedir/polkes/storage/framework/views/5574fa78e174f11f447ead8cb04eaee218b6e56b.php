

<?php $__env->startSection('content'); ?>
      
        <div class="col-md-3">
          <div class="card">
            <div class="card-body">
              <img src="<?php echo e(asset('img/profile/'.$user->foto_profile)); ?>" alt="" class="rounded-circle img-fluid"><br><br>
              <h5 class="text-center"><b><?php echo e($user->name); ?></b> <br> 
              Akses : 
              <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <span class="badge bg-primary rounded-3 fw-semibold mt-2"><small><?php echo e($a->name); ?></small></span> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h5>
            </div>
          </div>
        </div>

        <div class="col-md-9">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title fw-semibold mb-4">
                <a href="<?php echo e(url('profile')); ?>" class="btn btn-outline-primary">Profile</a> &nbsp;&nbsp;
                <a href="<?php echo e(route('changePassword')); ?>" class="btn btn-<?php echo e((request()->segment(1) == 'changePassword')? '':'outline-'); ?>primary">Password</a>
              </h5>

              <form method="POST" action="<?php echo e(route('changePassword')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group<?php echo e($errors->has('current-password') ? ' has-error' : ''); ?> mb-3 row">
                  <label for="current-password" class="col-sm-3 col-form-label">Password Lama</label>
                  <div class="col-sm-9">
                    <input type="password" class="form-control" id="current-password" name="current-password" required>
                    <?php if($errors->has('current-password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('current-password')); ?></strong>
                    </span>
                    <?php endif; ?>
                  </div>
                </div>


                <div class="form-group<?php echo e($errors->has('new-password') ? ' has-error' : ''); ?> mb-3 row">
                  <label for="new-password" class="col-sm-3 col-form-label">Password Baru</label>
                  <div class="col-sm-9">
                    <input type="password" class="form-control" id="new-password" name="new-password" required>
                    <?php if($errors->has('new-password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('new-password')); ?></strong>
                    </span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="form-group<?php echo e($errors->has('new-password') ? ' has-error' : ''); ?> mb-3 row">
                  <label for="new-password-confirm" class="col-sm-3 col-form-label">Konfirmasi Password</label>
                  <div class="col-sm-9">
                    <input type="password" class="form-control" id="new-password-confirm" name="new-password-confirm" required>
                  </div>
                </div>

                <button type="submit" class="btn btn-outline-primary">Update</button>
              </form>

            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adminlab/polkes/resources/views/auth/passwords/changepassword.blade.php ENDPATH**/ ?>