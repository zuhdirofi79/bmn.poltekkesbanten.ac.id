

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Jenis Peralatan Laboratorium</h5>
            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Nama</th>
                        <th>Ruangan</th>
                        <th>Tingkat</th>
                        <th>Nama Barang</th>
                        <th>Stok Pinjaman</th>
                        <th>Tgl Pinjaman</th>
                        
                        <th>Petugas Peminjaman</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $alat_lab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->name); ?></td>
                    <td><?php echo e($a->ruangan); ?></td>
                    <td><?php echo e($a->tingkat); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <td><?php echo e($a->stok_pinjam); ?></td>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    
                    <td><?php echo e($a->petugas_peminjaman); ?></td>
                    
                    <td><?php echo e($a->status); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Jenis Peralatan Medis</h5>
            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Nama</th>
                        <th>Ruangan</th>
                        <th>Tingkat</th>
                        <th>Nama Barang</th>
                        <th>Stok Pinjaman</th>
                        <th>Tgl Pinjaman</th>
                        
                        <th>Petugas Peminjaman</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                 <?php $__currentLoopData = $alat_medis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->name); ?></td>
                    <td><?php echo e($a->ruangan); ?></td>
                    <td><?php echo e($a->tingkat); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <td><?php echo e($a->stok_pinjam); ?></td>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    
                    <td><?php echo e($a->petugas_peminjaman); ?></td>
                    
                    <td><?php echo e($a->status); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Jenis Bahan BHP</h5>
            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Nama</th>
                        <th>Ruangan</th>
                        <th>Tingkat</th>
                        <th>Nama Barang</th>
                        <th>Stok Pinjaman</th>
                        <th>Tgl Pinjaman</th>
                        
                        <th>Petugas Peminjaman</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                 <?php $__currentLoopData = $bahan_bhp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->name); ?></td>
                    <td><?php echo e($a->ruangan); ?></td>
                    <td><?php echo e($a->tingkat); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <td><?php echo e($a->stok_pinjam); ?></td>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    
                    <td><?php echo e($a->petugas_peminjaman); ?></td>
                    
                    <td><?php echo e($a->status); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/belum_dikembalikan.blade.php ENDPATH**/ ?>