

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Peminjaman & Pengembalian Peralatan Detail <?php echo e($jurusan); ?></h5>
            <form action="<?php echo e(url('petugas/pengembalian_submit')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="peminjaman_id" value="<?php echo e($id); ?>">
            <table class="table table-bordered" style="width:100%">
                <thead style="background-color:#78faed;">
                    <tr>
                        <th width="30">No</th>
                        <th>Jenis</th>
                        <th>Nama Barang</th>
                        <th>Tgl Pinjaman</th>
                        <th>Tgl Pengembalian</th>
                        <th>Stok Pinjam</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input type="hidden" name="id[]" value="<?php echo e($a->id); ?>">
                  <input type="hidden" name="barang_id[]" value="<?php echo e($a->barang_id); ?>">
                  <input type="hidden" name="stok_pinjam[]" value="<?php echo e($a->stok_pinjam); ?>">
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->jenis); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    <td><?php echo e($a->tgl_pengembalian); ?></td>
                    <td><?php echo e($a->stok_pinjam); ?></td>
                    <td>
                      <select id="status" name="status[]" class="form-control" required>
                        <option value=""><?php echo e($a->status); ?></option>
                        <option value="Dikembalikan">Dikembalikan</option>
                        <?php if($a->jenis=='Peralatan Laboratorium'): ?>
                        <option value="Rusak">Rusak</option>
                        <option value="Hilang">Hilang</option>
                        <?php else: ?>
                        <option value="Habis Pakai">Habis Pakai</option>
                        <?php endif; ?>
                      </select>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div style="float: right;">
              <button class="btn btn-primary btn-sm" type="submit">Submit</button>
            </div>
            </form>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/pengembalian_detail.blade.php ENDPATH**/ ?>