[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/urbx6991/polkes/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>