

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a  href="<?php echo e(url('petugas/tambah_jadwal?jurusan='.$jurusan)); ?>" class="btn btn-outline-primary btn-sm"><span><i class="ti ti-plus"></i></span> Data Jadwal Praktek</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">JADWAL PRAKTEK LAB JURUSAN <?php echo e(strtoupper($jurusan)); ?> SEMESTER <?php echo e(strtoupper($semester->semester)); ?> <?php echo e($semester->ta); ?></h5>

            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Tanggal</th>
                        <th>Matakuliah</th>
                        <th>Tingkat</th>
                        <th>Ruangan Lab</th>
                        <th>Hari</th>
                        <th>Waktu Mulai</th>
                        <th>Waktu Selesai</th>
                        <th width="75">Detail</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->tgl); ?></td>
                    <td><?php echo e($a->kelas); ?></td>
                    <td><?php echo e($a->tingkat); ?></td>
                    <td><?php echo e($a->ruang); ?></td>
                    <td><?php echo e($a->hari); ?></td>
                    <td><?php echo e(substr($a->waktu_mulai,0,5)); ?></td>
                    <td><?php echo e(substr($a->waktu_selesai,0,5)); ?></td>
                    <td><a href="<?php echo e(url('petugas/detail_jadwal/'.$a->id)); ?>" class="btn btn-outline-primary btn-sm"><span><i class="ti ti-edit fs-4"></i></span></a>
                    <button class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#ModalDelete<?php echo e($a->id); ?>"><span><i class="ti ti-trash fs-4"></i></span></button></td>
                  </tr>

                  <!-- Modal edit barang-->
                    <div class="modal fade" id="ModalDelete<?php echo e($a->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                        <form action="<?php echo e(url('petugas/delete_jadwal')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Hapus data Jadwal Praktukim</h5>
                            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                          </div>
                          <div class="modal-body">

                            <p>Apakah Anda yakin ingin menghapus jadwal ini?</p>

                            <!-- <div class="form-group">
                              <label for="keterangan">Apakah Anda yakin ingin menghapus jadwal ini?</label>
                              <textarea class="form-control" id="keterangan" name="delete" required></textarea>
                            </div> -->

                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger">Delete</button>
                          </div>
                        </form>
                        </div>
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

          </div>
        </div>
      </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/urbx6991/polkes/resources/views/petugas_lab/ruang.blade.php ENDPATH**/ ?>