

<?php $__env->startSection('content'); ?>
      
        <div class="col-md-3">
          <div class="card">
            <div class="card-body">
              <img src="<?php echo e(asset('img/profile/'.$user->foto_profile)); ?>" alt="" class="rounded-circle img-fluid"><br><br>
              <h5 class="text-center">
                <!-- <button class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#exampleModal">Upload Foto Profile</button> <br><br> -->
                <b><?php echo e($user->name); ?></b> <br> 
              Akses :
              <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <span class="badge bg-primary rounded-3 fw-semibold mt-2"><small><?php echo e($a->name); ?></small></span> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </h5>
            </div>
          </div>
        </div>

        <div class="col-md-9">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title fw-semibold mb-4">
                <a href="<?php echo e(url('profile')); ?>" class="btn btn-<?php echo e((request()->segment(1) == 'profile')? '':'outline-'); ?>primary">Profile</a> &nbsp;&nbsp;
                <a href="<?php echo e(route('changePassword')); ?>" class="btn btn-outline-primary">Password</a>
              </h5>

              <form action="<?php echo e(url('update_profile')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3 row">
                  <label for="name" class="col-sm-2 col-form-label">Nama Lengkap</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>" disabled>
                  </div>
                </div>

                <div class="form-group mb-3 row">
                  <label for="username" class="col-sm-2 col-form-label">
                    <?php if($user->role=='mahasiswa'): ?>
                      NIM
                    <?php elseif($user->role=='dosen'): ?>
                      NID
                    <?php else: ?>
                      NIP/NUP
                    <?php endif; ?>
                  </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username); ?>" disabled>
                  </div>
                </div>

                <?php if($user->role=='mahasiswa' or $user->role=='dosen'): ?>
                <div class="form-group mb-3 row">
                  <label for="jurusan" class="col-sm-2 col-form-label">Jurusan</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="jurusan" name="jurusan" value="<?php echo e($user->jurusan); ?>" disabled>
                  </div>
                </div>
                <?php endif; ?>

                <div class="form-group mb-3 row">
                  <label for="email" class="col-sm-2 col-form-label">E-Mail</label>
                  <div class="col-sm-10">
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>
                  </div>
                </div>

                <div class="form-group mb-3 row">
                  <label for="jenis_kelamin" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                  <div class="col-sm-10">
                    <select id="jenis_kelamin" name="jenis_kelamin" class="form-control" required>
                      <option <?php if($user->foto_profile=='default.png'): ?> selected <?php endif; ?>>--Pilih--</option>
                      <option value="Laki-laki" <?php if($user->foto_profile=='male.png'): ?> selected <?php endif; ?> >Laki-laki</option>
                      <option value="Perempuan" <?php if($user->foto_profile=='female.png'): ?> selected <?php endif; ?> >Perempuan</option>
                    </select>
                  </div>
                </div>

                <div class="form-group mb-3 row">
                  <label for="no_hp" class="col-sm-2 col-form-label">No HP</label>
                  <div class="col-sm-10">
                    <input type="number" class="form-control" id="no_hp" name="no_hp" value="<?php echo e($user->no_hp); ?>" required>
                  </div>
                </div>

                <button type="submit" class="btn btn-outline-primary">Update</button>
              </form>

            </div>
          </div>
        </div>

    <!-- Modal foto profile-->
    <div class="modal fade" id="exampleModal" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('upload_foto')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Upload Foto Profile</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="foto_profile" class="col-sm-3 col-form-label">Foto Profile</label>
              <div class="col-sm-9">
                <input type="file" class="form-control" id="foto_profile" name="foto_profile" required>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Upload</button>
          </div>
        </form>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adminlab/polkes/resources/views/profile.blade.php ENDPATH**/ ?>