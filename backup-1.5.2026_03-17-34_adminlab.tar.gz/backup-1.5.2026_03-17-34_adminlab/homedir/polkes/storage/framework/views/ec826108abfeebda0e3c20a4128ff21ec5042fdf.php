

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Laporan Pinjaman</h5>

                <p><b>Lihat Laporan</b></p>

                <form action="<?php echo e(url('petugas/laporan_pinjaman')); ?>" method="get">
                
                <div style="" class="d-flex justify-content-center">
                <input type="date" class="form-control" id="tgl_awal" name="tgl_awal" style="width:300px;" required value="<?php echo e($tgl_awal); ?>">
                 &nbsp; &nbsp; Sampai Dengan &nbsp; &nbsp;
                <input type="date" class="form-control" id="tgl_akhir" name="tgl_akhir" style="width:300px;" required value="<?php echo e($tgl_akhir); ?>">
                 &nbsp;
                <button type="submit" class="btn btn-outline-primary">Submit</button>
                </div>
                </form>
                <br>

                <?php if($laporan_pinjaman): ?>

                <div style="float: left;">
                  <a href="<?php echo e(url('petugas/print_lap_pinjaman?tgl_awal='.$tgl_awal.'&tgl_akhir='.$tgl_akhir)); ?>" class="btn btn-outline-primary btn-sm" target="_blank"><i class="ti ti-printer"></i> Print</a>
                </div>
                    <table id="example1" class="table table-bordered table-striped table-sm">
                      <thead>
                      <tr>
                        <th width="30">No</th>
                        <th>Tgl Pinjam</th>
                        <th>Nama</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Petugas</th>
                      </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $laporan_pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e(substr($a->tgl_pinjaman,0,10)); ?></td>
                        <td><?php echo e($a->name); ?></td>
                        <td><?php echo e($a->kode_barang); ?></td>
                        <td><?php echo e($a->nama_barang); ?></td>
                        <td><?php echo e($a->stok_pinjaman); ?></td>
                        <td><?php echo e($a->status); ?></td>
                        <td><?php echo e($a->petugas); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                <?php endif; ?>

          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/laporan_pinjaman.blade.php ENDPATH**/ ?>