

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card col-sm-8">
          <div class="card-body row">
            <h5 class="card-title fw-semibold mb-4">User Edit </h5>
            <br>

            <div class="col-sm-12">
              <div class="form-group mb-3 row">
                <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="nama" value="<?php echo e($user->name); ?>" disabled>
                </div>
              </div>

              <div class="form-group mb-3 row">
                <label for="nama" class="col-sm-2 col-form-label">NIM/NID</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="nama" value="<?php echo e($user->username); ?>" disabled>
                </div>
              </div>

              <div class="form-group mb-3 row">
                <label for="email" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" id="email" Value="<?php echo e($user->email); ?>" disabled>
                </div>
              </div>
            </div>

            <div class="col-sm-6">
              <p><b>Role yang dimiliki</b></p>
              <table class="table table-bordered table-sm">
                <thead>
                  <?php $__currentLoopData = $role_have; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($a->name); ?></td>
                    <td><a href="<?php echo e(url('admin/delete_role_user/'.$id.'/'.$a->role_id)); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Apakah anda yakin ingin menghapus role <?php echo e($a->name); ?> ?')">Delete</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </thead>
              </table>
            </div>
            <div class="col-sm-6">
              <p><b>Role yang tidak dimiliki</b></p>
              <table class="table table-bordered table-sm">
                <thead>
                  <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($a->name); ?></td>
                    <td><a href="<?php echo e(url('admin/add_role_user/'.$id.'/'.$a->id)); ?>" class="btn btn-outline-primary btn-sm" onclick="return confirm('Apakah anda yakin ingin menambah role <?php echo e($a->name); ?> ?')">Add</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </thead>
              </table>
            </div>
          </div>

          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/admin/user_edit.blade.php ENDPATH**/ ?>