<?php echo e($slot); ?>

<?php /**PATH /home/urbx6991/polkes/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>