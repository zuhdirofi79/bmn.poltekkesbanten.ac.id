

<?php $__env->startSection('content'); ?>
      <div class="container-fluid col-lg-9">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">TAMBAH JADWAL PRAKTEK LAB JURUSAN <?php echo e(strtoupper($jurusan)); ?></h5>

            <form action="<?php echo e(url('petugas/add_jadwal')); ?>" method="post">
              <?php echo csrf_field(); ?>
                <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
                
                <div class="form-group mb-3 row">
                    <label for="tgl" class="col-sm-3 col-form-label">Tanggal</label>
                    <div class="col-sm-9">
                      <input type="date" class="form-control" id="tgl" name="tgl" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="penanggung_jawab" class="col-sm-3 col-form-label">Penanggung Jawab/Dosen</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="penanggung_jawab" name="penanggung_jawab" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="kelas" class="col-sm-3 col-form-label">Matakuliah</label>
                    <div class="col-sm-9">
                      <select id="kelas" name="kelas" class="form-control" required>
                        <option value=""></option>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($e->matkul); ?>"><?php echo e($e->matkul); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>

                  <div class="form-group mb-3 row" id="otherKelas" style="display:none;">
                    <label for="kelas_other" class="col-sm-3 col-form-label"></label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="kelas_other" name="kelas_other">
                    </div>
                  </div>
                  
                  <div class="form-group mb-3 row">
                    <label for="tingkat" class="col-sm-3 col-form-label">Tingkat</label>
                    <div class="col-sm-9">
                      <select id="tingkat" name="tingkat" class="form-control" required>
                        <option value=""></option>
                        <?php $__currentLoopData = $tingkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($d->tingkat); ?>"><?php echo e($d->tingkat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>

                  <div class="form-group mb-3 row" id="otherTingkat" style="display:none;">
                    <label for="tingkat_other" class="col-sm-3 col-form-label"></label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="tingkat_other" name="tingkat_other">
                    </div>
                  </div>

                 <div class="form-group mb-3 row">
                    <label for="ruang" class="col-sm-3 col-form-label">Ruang</label>
                    <div class="col-sm-9">
                      <select id="ruang" name="ruang" class="form-control" required>
                        <option value=""></option>
                        <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($b->nama_ruang); ?>"><?php echo e($b->kampus); ?> - <?php echo e($b->nama_ruang); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="hari" class="col-sm-3 col-form-label">Hari</label>
                    <div class="col-sm-9">
                      <select id="hari" name="hari" class="form-control" required>
                        <option value=""></option>
                        <?php $__currentLoopData = $hari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($c->hari); ?>"><?php echo e($c->hari); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="waktu_mulai" class="col-sm-3 col-form-label">Waktu Mulai</label>
                    <div class="col-sm-9">
                      <input type="time" class="form-control" id="waktu_mulai" name="waktu_mulai" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="waktu_selesai" class="col-sm-3 col-form-label">Waktu Selesai</label>
                    <div class="col-sm-9">
                      <input type="time" class="form-control" id="waktu_selesai" name="waktu_selesai" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="tujuan" class="col-sm-3 col-form-label">Tujuan</label>
                    <div class="col-sm-9">
                      <select id="tujuan" name="tujuan" class="form-control" required>
                          <option>--Pilih--</option>
                          <?php $__currentLoopData = $tujuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($f->tujuan); ?>"><?php echo e($f->tujuan); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>

                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
              </form>

          </div>
        </div>
      </div>


  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script>
      $(document).ready(function () {
          // Ketika nilai dalam select berubah
          $("#kelas").change(function () {
              // Jika nilai yang dipilih adalah "other"
              if ($(this).val() == "Other") {
                  // Tampilkan form input tambahan
                  $("#otherKelas").show();
              } else {
                  // Sembunyikan form input tambahan
                  $("#otherKelas").hide();
              }
          });
      });

      $(document).ready(function () {
          // Ketika nilai dalam select berubah
          $("#tingkat").change(function () {
              // Jika nilai yang dipilih adalah "other"
              if ($(this).val() == "Other") {
                  // Tampilkan form input tambahan
                  $("#otherTingkat").show();
              } else {
                  // Sembunyikan form input tambahan
                  $("#otherTingkat").hide();
              }
          });
      });
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema_select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/urbx6991/polkes/resources/views/petugas_lab/add_jadwal.blade.php ENDPATH**/ ?>