

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4"><?php echo e($title); ?></h5>
            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="30">No</th>
                        <th>NIM/NID</th>
                        <th>Nama</th>
                        <th>Tgl Permintaan</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Status</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->username); ?></td>
                    <td><?php echo e($a->name); ?></td>
                    <td><?php echo e(substr($a->tgl_request,0,10)); ?></td>
                    <td><?php echo e($a->kode_barang); ?></td>
                    <td><?php echo e($a->nama_barang); ?></td>
                    <td>
                      <?php if($a->status=='Menunggu Konfirmasi'): ?> 
                      <span class="badge bg-dark rounded-3 fw-semibold"><small><?php echo e($a->status); ?></small></span>
                      <?php elseif($a->status=='Ditolak'): ?> 
                      <span class="badge bg-danger rounded-3 fw-semibold"><small><?php echo e($a->status); ?></small></span>
                      <?php elseif($a->status=='Dipinjam'): ?> 
                      <span class="badge bg-primary rounded-3 fw-semibold"><small><?php echo e($a->status); ?></small></span>
                      <?php else: ?>
                      <span class="badge bg-success rounded-3 fw-semibold"><small><?php echo e($a->status); ?></small></span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <a href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" 
                      data-target="#exampleModal<?php echo e($a->id); ?>">Detail</a>
                    </td>
                  </tr>

                  <!-- Modal add request-->
                  <div class="modal fade" id="exampleModal<?php echo e($a->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <form action="<?php echo e(url('petugas/edit_request')); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                          <input type="hidden" name="kode_barang" value="<?php echo e($a->kode_barang); ?>">
                          <input type="hidden" name="kategori" value="<?php echo e($a->kategori); ?>">
                          <input type="hidden" name="username" value="<?php echo e($a->username); ?>">
                          <input type="hidden" name="name" value="<?php echo e($a->name); ?>">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Detail Request Pinjaman Barang</h5>
                          <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                        </div>
                        <div class="modal-body">

                          <div class="form-group mb-3 row">
                            <label for="username" class="col-sm-3 col-form-label">NIM/NID</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="username" name="username" value="<?php echo e($a->username); ?>" required disabled>
                            </div>
                          </div>

                          <div class="form-group mb-3 row">
                            <label for="name" class="col-sm-3 col-form-label">Nama</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="name" name="name" value="<?php echo e($a->name); ?>" required disabled>
                            </div>
                          </div>

                          <div class="form-group mb-3 row">
                            <label for="kode_barang" class="col-sm-3 col-form-label">Barang</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="kode_barang" name="kode_barang" value="<?php echo e($a->kode_barang); ?> - <?php echo e($a->nama_barang); ?>" required disabled>
                            </div>
                          </div>

                          <div class="form-group mb-3 row">
                            <label for="kategori" class="col-sm-3 col-form-label">Kategori</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="kategori" name="kategori" value="<?php echo e($a->kategori); ?>" required disabled>
                            </div>
                          </div>

                          <div class="form-group mb-3 row">
                            <label for="stok_pinjaman" class="col-sm-3 col-form-label">Sejumlah</label>
                            <div class="col-sm-9">
                              <input type="number" class="form-control" id="stok_pinjaman" name="stok_pinjaman" value="<?php echo e($a->stok_pinjaman); ?>" required>
                            </div>
                          </div>

                          <div class="form-group mb-3 row">
                            <label for="keperluan" class="col-sm-3 col-form-label">Keperluan</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="keperluan" name="keperluan" value="<?php echo e($a->keperluan); ?>" required>
                            </div>
                          </div>

                          <?php if($a->kategori != 'Perlengkapan Sekali Pakai'): ?>
                          <div class="form-group mb-3 row">
                            <label for="kode_barang" class="col-sm-3 col-form-label">Status</label>
                            <div class="col-sm-9">
                              <select id="status" name="status" class="form-control" required>
                                <!-- <option value="Menunggu Konfirmasi" <?php echo e(($a->status == 'Menunggu Konfirmasi')? 'selected':''); ?>>Menunggu Konfirmasi</option> -->
                                <option value="Ditolak" <?php echo e(($a->status == 'Ditolak')? 'selected':''); ?>>Ditolak</option>
                                <option value="Dipinjam" <?php echo e(($a->status == 'Dipinjam')? 'selected':''); ?>>Dipinjam</option>
                                <option value="Sudah Dikembalikan" <?php echo e(($a->status == 'Sudah Dikembalikan')? 'selected':''); ?>>Sudah Dikembalikan</option>
                              </select>
                            </div>
                          </div>
                          <?php else: ?>
                          <div class="form-group mb-3 row">
                            <label for="kode_barang" class="col-sm-3 col-form-label">Status</label>
                            <div class="col-sm-9">
                              <select id="status" name="status" class="form-control" required>
                                <!-- <option value="Menunggu Konfirmasi" <?php echo e(($a->status == 'Menunggu Konfirmasi')? 'selected':''); ?>>Menunggu Konfirmasi</option> -->
                                <option value="Ditolak" <?php echo e(($a->status == 'Ditolak')? 'selected':''); ?>>Ditolak</option>
                                <option value="Barang sekali pakai tidak perlu dikembalikan" <?php echo e(($a->status == 'Barang sekali pakai tidak perlu dikembalikan')? 'selected':''); ?>>Barang sekali pakai tidak perlu dikembalikan</option>
                              </select>
                            </div>
                          </div>
                          <?php endif; ?>

                          <div class="form-group mb-3 row">
                            <label for="tgl_pinjaman" class="col-sm-3 col-form-label">Tanggal Pinjaman</label>
                            <div class="col-sm-9">
                              <input type="date" class="form-control" id="tgl_pinjaman" name="tgl_pinjaman" value="<?php echo e($a->tgl_pinjaman); ?>">
                            </div>
                          </div>

                          <?php if($a->kategori != 'Perlengkapan Sekali Pakai'): ?>
                          <div class="form-group mb-3 row">
                            <label for="tgl_pengembalian" class="col-sm-3 col-form-label">Tanggal Pengembalian</label>
                            <div class="col-sm-9">
                              <input type="date" class="form-control" id="tgl_pengembalian" name="tgl_pengembalian" value="<?php echo e($a->tgl_pengembalian); ?>">
                            </div>
                          </div>
                          <?php endif; ?>

                          <div class="form-group mb-3 row">
                            <label for="keterangan" class="col-sm-3 col-form-label">Keterangan</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="keterangan" name="keterangan" value="<?php echo e($a->keterangan); ?>">
                              <small class="form-text text-muted">opsional</small>
                            </div>
                          </div>

                          <?php if($a->status != 'Menunggu Konfirmasi'): ?>
                          <div class="form-group mb-3 row">
                            <label for="petugas" class="col-sm-3 col-form-label">Petugas Lab</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="petugas" name="petugas" value="<?php echo e($a->petugas); ?>" required disabled>
                            </div>
                          </div>
                          <?php endif; ?>

                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                      </div>
                      </form>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\polkes\resources\views/petugas_lab/request.blade.php ENDPATH**/ ?>