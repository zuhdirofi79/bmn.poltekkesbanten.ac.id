

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Users</h5>
            <p class="mb-0">This is a sample page </p>

            <i class="fas fa-bell"></i> <!-- Ikon lonceng -->
<i class="far fa-heart"></i> <!-- Ikon hati kosong -->
            <br>

            <table id="myTable" class="table table-striped table-bordered table-sm" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIM/NID</th>
                        <th>Nama</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($a->username); ?></td>
                        <td><?php echo e($a->name); ?></td>
                        <td><a href="<?php echo e(url('admin/user_edit/'.$a->id)); ?>" target="_blank" class="btn btn-outline-primary btn-sm"><span><i class="ti ti-edit"></i></span></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>NIM/NID</th>
                        <th>Nama</th>
                        <th>Edit</th>
                    </tr>
                </tfoot>
            </table>

          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\polkes\resources\views/admin/user_manage.blade.php ENDPATH**/ ?>