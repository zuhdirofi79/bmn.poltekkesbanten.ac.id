

<?php $__env->startSection('content'); ?>
      
        <div class="col-md-3">
          <div class="card">
            <div class="card-body">
              <img src="<?php echo e(asset('img/profile/'.$user->foto_profile)); ?>" alt="" class="rounded-circle img-fluid"><br><br>
              <h5 class="text-center">
                <b><?php echo e($user->name); ?></b> <br> 
              Akses :
              <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <span class="badge bg-primary rounded-3 fw-semibold mt-2"><small><?php echo e($a->name); ?></small></span> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </h5>
            </div>
          </div>
        </div>

        <div class="col-md-9">
          <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-4">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                  <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Profile</a>
                  </li>
                  <li class="nav-item" role="presentation">
                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Reset Password</a>
                  </li>
                </ul>
                </h5>

                <div class="tab-content" id="myTabContent">
                  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <form action="<?php echo e(url('admin/user_update')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                      <div class="form-group mb-3 row">
                        <label for="name" class="col-sm-2 col-form-label">Nama Lengkap</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>" required>
                        </div>
                      </div>
                      <div class="form-group mb-3 row">
                        <label for="username" class="col-sm-2 col-form-label">
                          <?php if($user->role=='mahasiswa'): ?>
                            NIM
                          <?php elseif($user->role=='dosen'): ?>
                            NID
                          <?php else: ?>
                            NIP/NUP
                          <?php endif; ?>
                        </label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username); ?>" required>
                        </div>
                      </div>
                      <?php if($user->role=='mahasiswa'): ?>
                      <div class="form-group mb-3 row">
                        <label for="jurusan" class="col-sm-2 col-form-label">Jurusan</label>
                        <div class="col-sm-10">
                          <select id="jurusan" name="jurusan" class="form-control" required>
                            <option value="TLM" <?php if($user->jurusan=='TLM'): ?> selected <?php endif; ?>>TLM</option>
                            <option value="Kebidanan" <?php if($user->jurusan=='Kebidanan'): ?> selected <?php endif; ?>>Kebidanan</option>
                            <option value="Keperawatan" <?php if($user->jurusan=='Keperawatan'): ?> selected <?php endif; ?>>Keperawatan</option>
                          </select>
                        </div>
                      </div>
                      <?php endif; ?>
                      <div class="form-group mb-3 row">
                        <label for="email" class="col-sm-2 col-form-label">E-Mail</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>
                        </div>
                      </div>
                      <div class="form-group mb-3 row">
                        <label for="jenis_kelamin" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                        <div class="col-sm-10">
                          <select id="jenis_kelamin" name="jenis_kelamin" class="form-control" required>
                            <option <?php if($user->foto_profile=='default.png'): ?> selected <?php endif; ?>>--Pilih--</option>
                            <option value="Laki-laki" <?php if($user->foto_profile=='male.png'): ?> selected <?php endif; ?> >Laki-laki</option>
                            <option value="Perempuan" <?php if($user->foto_profile=='female.png'): ?> selected <?php endif; ?> >Perempuan</option>
                          </select>
                        </div>
                      </div>
                      <div class="form-group mb-3 row">
                        <label for="no_hp" class="col-sm-2 col-form-label">No HP</label>
                        <div class="col-sm-10">
                          <input type="number" class="form-control" id="no_hp" name="no_hp" value="<?php echo e($user->no_hp); ?>" required>
                        </div>
                      </div>
                      <button type="submit" class="btn btn-outline-primary">Update</button>
                    </form>
                  </div>

                  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <form method="POST" action="<?php echo e(url('admin/user_reset')); ?>">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="id" value="<?php echo e($user->id); ?>">

                      <div class="form-group<?php echo e($errors->has('new-password') ? ' has-error' : ''); ?> mb-3 row">
                        <label for="new-password" class="col-sm-3 col-form-label">Password Baru</label>
                        <div class="col-sm-9">
                          <input type="password" class="form-control" id="new-password" name="new-password" required>
                          <?php if($errors->has('new-password')): ?>
                          <span class="help-block">
                              <strong><?php echo e($errors->first('new-password')); ?></strong>
                          </span>
                          <?php endif; ?>
                        </div>
                      </div>

                      <div class="form-group<?php echo e($errors->has('new-password') ? ' has-error' : ''); ?> mb-3 row">
                        <label for="new-password-confirm" class="col-sm-3 col-form-label">Konfirmasi Password</label>
                        <div class="col-sm-9">
                          <input type="password" class="form-control" id="new-password-confirm" name="new-password-confirm" required>
                        </div>
                      </div>

                      <button type="submit" class="btn btn-outline-primary">Update</button>
                    </form>
                  </div>

                </div>
              

              

            </div>
          </div>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/admin/user_detail.blade.php ENDPATH**/ ?>