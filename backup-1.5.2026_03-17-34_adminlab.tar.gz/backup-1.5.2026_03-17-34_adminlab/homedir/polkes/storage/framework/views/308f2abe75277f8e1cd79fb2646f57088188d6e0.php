
<?php $__env->startSection('content'); ?>

<?php $b = array(); ?>
    <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php $b[$loop->iteration] = $a->bobot_perbaikan; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
            <h4>PEMILIHAN HARGA DAN KUALITAS HANDPHONE TERBAIK MENGGUNAKAN METODE WP</h4>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <?php if(session('message')): ?>
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <div class='alert alert-success'>
                <?php echo e(session('message')); ?>

            </div>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
     <?php endif; ?>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Alternatif</h3>
                <div class="float-right">
                  <a href="" class="btn btn-outline-primary" data-toggle="modal" data-target="#exampleModal">+ Tambah data alternatif</a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Code</th>
                    <th>Nama Handphone</th>
                    <th>Harga</th>
                    <th>Kualitas</th>
                    <th>Fitur</th>
                    <th>Populer</th>
                    <th>Purna Jual</th>
                    <th>Keawetan</th>
                    <th>#</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->code); ?></td>
                    <td><?php echo e($a->nama_hp); ?></td>
                    <td>Rp. <?php echo e(number_format($a->harga, 0, ",", ".")); ?></td>
                    <td><?php echo e($a->kualitas); ?></td>
                    <td><?php echo e($a->fitur); ?></td>
                    <td><?php echo e($a->populer); ?></td>
                    <td>Rp. <?php echo e(number_format($a->purna_jual, 0, ",", ".")); ?></td>
                    <td><?php echo e($a->keawetan); ?></td>
                    <td>
                      <a href="" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#editModal<?php echo e($loop->iteration); ?>"><i class="nav-icon fas fa-edit"></i></a>
                      <a href="<?php echo e(url('wp/delete/'.$a->id)); ?>" class="btn btn-outline-danger btn-sm" onclick="(confirm('Anda yakin ingin menghapus data ini?'))"><i class="nav-icon fas fa-trash"></i></a>
                    </td>
                  </tr>


                  <!-- Modal edit-->
                  <div class="modal fade" id="editModal<?php echo e($loop->iteration); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                        <form action="<?php echo e(url('wp/update')); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="b1" value="<?php echo e($b[1]); ?>">
                          <input type="hidden" name="b2" value="<?php echo e($b[2]); ?>">
                          <input type="hidden" name="b3" value="<?php echo e($b[3]); ?>">
                          <input type="hidden" name="b4" value="<?php echo e($b[4]); ?>">
                          <input type="hidden" name="b5" value="<?php echo e($b[5]); ?>">
                          <input type="hidden" name="b6" value="<?php echo e($b[6]); ?>">
                          <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Update Data</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">

                          <div class="form-group row">
                            <label for="code" class="col-sm-3 col-form-label">Code</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="code" name="code" value="<?php echo e($a->code); ?>" required>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="nama_hp" class="col-sm-3 col-form-label">Nama Hanhdphone</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="nama_hp" name="nama_hp" value="<?php echo e($a->nama_hp); ?>" required>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="harga" class="col-sm-3 col-form-label">Harga</label>
                            <div class="col-sm-9">
                              <div class="input-group-prepend">
                                <div class="input-group-text">Rp.</div>
                                <input type="number" class="form-control" id="harga" name="harga" value="<?php echo e($a->harga); ?>" required>
                              </div>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="kualitas" class="col-sm-3 col-form-label">Kualitas</label>
                            <div class="col-sm-9">
                              <select class="form-control" id="kualitas" name="kualitas" required>
                                <option value="Sangat Buruk" <?php if($a->kualitas === 'Sangat Buruk'){echo 'selected';} ?> >Sangat Buruk</option>
                                <option value="Buruk" <?php if($a->kualitas === 'Buruk'){echo 'selected';} ?> >Buruk</option>
                                <option value="Kurang Baik" <?php if($a->kualitas === 'Kurang Baik'){echo 'selected';} ?> >Kurang Baik</option>
                                <option value="Baik" <?php if($a->kualitas === 'Baik'){echo 'selected';} ?> >Baik</option>
                                <option value="Sangat Baik" <?php if($a->kualitas === 'Sangat Baik'){echo 'selected';} ?> >Sangat Baik</option>
                              </select>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="fitur" class="col-sm-3 col-form-label">Fitur</label>
                            <div class="col-sm-9">
                              <select class="form-control" id="fitur" name="fitur" required>
                                <option value="Sangat Buruk" <?php echo $a->fitur == 'Sangat Buruk'? 'selected' : ''; ?> >Sangat Buruk</option>
                                <option value="Buruk" <?php echo $a->fitur == 'Buruk'? 'selected' : ''; ?>>Buruk</option>
                                <option value="Kurang Baik" <?php echo $a->fitur == 'Kurang Baik'? 'selected' : ''; ?>>Kurang Baik</option>
                                <option value="Baik" <?php echo $a->fitur == 'Baik'? 'selected' : ''; ?>>Baik</option>
                                <option value="Sangat Baik" <?php echo $a->fitur == 'Sangat Baik'? 'selected' : ''; ?>>Sangat Baik</option>
                              </select>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="populer" class="col-sm-3 col-form-label">Populer</label>
                            <div class="col-sm-9">
                              <select class="form-control" id="populer" name="populer" required>
                                <option value="Sangat Buruk" <?php echo $a->populer == 'Sangat Buruk'? 'selected' : ''; ?> >Sangat Buruk</option>
                                <option value="Buruk" <?php echo $a->populer == 'Buruk'? 'selected' : ''; ?>>Buruk</option>
                                <option value="Kurang Baik" <?php echo $a->populer == 'Kurang Baik'? 'selected' : ''; ?>>Kurang Baik</option>
                                <option value="Baik" <?php echo $a->populer == 'Baik'? 'selected' : ''; ?>>Baik</option>
                                <option value="Sangat Baik" <?php echo $a->populer == 'Sangat Baik'? 'selected' : ''; ?>>Sangat Baik</option>
                              </select>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="purna_jual" class="col-sm-3 col-form-label">Purna Jual</label>
                            <div class="col-sm-9">
                              <div class="input-group-prepend">
                                <div class="input-group-text">Rp.</div>
                                <input type="number" class="form-control" id="purna_jual" name="purna_jual" value="<?php echo e($a->purna_jual); ?>" required>
                              </div>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="keawetan" class="col-sm-3 col-form-label">Keawetan</label>
                            <div class="col-sm-9">
                              <select class="form-control" id="keawetan" name="keawetan" required>
                                <option value="Sangat Buruk" <?php echo $a->keawetan == 'Sangat Buruk'? 'selected' : ''; ?> >Sangat Buruk</option>
                                <option value="Buruk" <?php echo $a->keawetan == 'Buruk'? 'selected' : ''; ?>>Buruk</option>
                                <option value="Kurang Baik" <?php echo $a->keawetan == 'Kurang Baik'? 'selected' : ''; ?>>Kurang Baik</option>
                                <option value="Baik" <?php echo $a->keawetan == 'Baik'? 'selected' : ''; ?>>Baik</option>
                                <option value="Sangat Baik" <?php echo $a->keawetan == 'Sangat Baik'? 'selected' : ''; ?>>Sangat Baik</option>
                              </select>
                            </div>
                          </div>
                          
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                        </form>
                      </div>
                    </div>
                  </div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>


    <section class="content">
      <div class="container-fluid">
        <div class="row">

          <div class="col-7">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Kriteria</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Code</th>
                    <th>Kriteria</th>
                    <th>Tipe</th>
                    <th>Bobot</th>
                    <th>Rumus</th>
                    <th>Bobot Perbaikan</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($a->code); ?></td>
                    <td><?php echo e($a->kriteria); ?></td>
                    <td><?php echo e($a->tipe); ?></td>
                    <td><?php echo e($a->bobot); ?></td>
                    <td><?php echo e($a->bobot); ?>/<?php echo e($total_bobot); ?></td>
                    <td><?php echo e($a->bobot_perbaikan); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td colspan="3"><h4><b>TOTAL</b></h4></td>
                    <td><h4><b><?php echo e($total_bobot); ?></b></h4></td>
                    <td></td>
                    <td><h4><b><?php echo e($total_bobot_perbaikan); ?></b></h4></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>

          <div class="col-5">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Variabel Kriteria Kualitas , Fitur, Populer, Keawetan</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Bobot</th>
                    <th>Keterangan</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $variabel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($a->id); ?></td>
                    <td><?php echo e($a->ket); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->

        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Konfersi Nilai Variabel</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Code</th>
                    <th>C1</th>
                    <th>C2</th>
                    <th>C3</th>
                    <th>C4</th>
                    <th>C5</th>
                    <th>C6</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->code); ?></td>
                    <td><?php echo e($a->c1); ?></td>
                    <td><?php echo e($a->c2); ?></td>
                    <td><?php echo e($a->c3); ?></td>
                    <td><?php echo e($a->c4); ?></td>
                    <td><?php echo e($a->c5); ?></td>
                    <td><?php echo e($a->c6); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>


    <section class="content">
      <div class="container-fluid">
        <div class="row">

          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Hasil Vektor S</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Code</th>
                    <th>Rumus</th>
                    <th>Hasil Vektor S</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($a->code); ?></td>
                    <td>
                      ( <?php echo e($a->c1); ?><sup>-<?php echo e($b[1]); ?></sup> )*( <?php echo e($a->c2); ?><sup><?php echo e($b[2]); ?></sup> )*( <?php echo e($a->c3); ?><sup><?php echo e($b[3]); ?></sup> )*
                      ( <?php echo e($a->c4); ?><sup><?php echo e($b[4]); ?></sup> )*( <?php echo e($a->c5); ?><sup><?php echo e($b[5]); ?></sup> )*( <?php echo e($a->c6); ?><sup><?php echo e($b[6]); ?></sup> )
                    </td>
                    <td><?php echo e($a->vektor_s); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td colspan="2"><h4><b>TOTAL VEKTOR S</b></h4></td>
                    <td><h4><b><?php echo e($total_vektor_s); ?></b></h4></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>

          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Hasil Vektor V</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Code</th>
                    <th>Rumus</th>
                    <th>Hasil Vektor V</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($a->code); ?></td>
                    <td><?php echo e($a->vektor_s); ?> / <?php echo e($total_vektor_s); ?></td>
                    <td><?php echo e($a->vektor_s/$total_vektor_s); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->

        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="<?php echo e(url('wp/insert')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="b1" value="<?php echo e($b[1]); ?>">
        <input type="hidden" name="b2" value="<?php echo e($b[2]); ?>">
        <input type="hidden" name="b3" value="<?php echo e($b[3]); ?>">
        <input type="hidden" name="b4" value="<?php echo e($b[4]); ?>">
        <input type="hidden" name="b5" value="<?php echo e($b[5]); ?>">
        <input type="hidden" name="b6" value="<?php echo e($b[6]); ?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <div class="form-group row">
          <label for="code" class="col-sm-3 col-form-label">Code</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" id="code" name="code" required>
          </div>
        </div>

        <div class="form-group row">
          <label for="nama_hp" class="col-sm-3 col-form-label">Nama Hanhdphone</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" id="nama_hp" name="nama_hp" required>
          </div>
        </div>

        <div class="form-group row">
          <label for="harga" class="col-sm-3 col-form-label">Harga</label>
          <div class="col-sm-9">
            <div class="input-group-prepend">
              <div class="input-group-text">Rp.</div>
              <input type="number" class="form-control" id="harga" name="harga" required>
            </div>
          </div>
        </div>

        <div class="form-group row">
          <label for="kualitas" class="col-sm-3 col-form-label">Kualitas</label>
          <div class="col-sm-9">
            <select class="form-control" id="kualitas" name="kualitas" required>
              <option>-- pilih -- </option>
              <option value="Sangat Buruk">Sangat Buruk</option>
              <option value="Buruk">Buruk</option>
              <option value="Kurang Baik">Kurang Baik</option>
              <option value="Baik">Baik</option>
              <option value="Sangat Baik">Sangat Baik</option>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <label for="fitur" class="col-sm-3 col-form-label">Fitur</label>
          <div class="col-sm-9">
            <select class="form-control" id="fitur" name="fitur" required>
              <option>-- pilih -- </option>
              <option value="Sangat Buruk">Sangat Buruk</option>
              <option value="Buruk">Buruk</option>
              <option value="Kurang Baik">Kurang Baik</option>
              <option value="Baik">Baik</option>
              <option value="Sangat Baik">Sangat Baik</option>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <label for="populer" class="col-sm-3 col-form-label">Populer</label>
          <div class="col-sm-9">
            <select class="form-control" id="populer" name="populer" required>
              <option>-- pilih -- </option>
              <option value="Sangat Buruk">Sangat Buruk</option>
              <option value="Buruk">Buruk</option>
              <option value="Kurang Baik">Kurang Baik</option>
              <option value="Baik">Baik</option>
              <option value="Sangat Baik">Sangat Baik</option>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <label for="purna_jual" class="col-sm-3 col-form-label">Purna Jual</label>
          <div class="col-sm-9">
            <div class="input-group-prepend">
              <div class="input-group-text">Rp.</div>
              <input type="number" class="form-control" id="purna_jual" name="purna_jual" required>
            </div>
          </div>
        </div>

        <div class="form-group row">
          <label for="keawetan" class="col-sm-3 col-form-label">Keawetan</label>
          <div class="col-sm-9">
            <select class="form-control" id="keawetan" name="keawetan" required>
              <option>-- pilih -- </option>
              <option value="Sangat Buruk">Sangat Buruk</option>
              <option value="Buruk">Buruk</option>
              <option value="Kurang Baik">Kurang Baik</option>
              <option value="Baik">Baik</option>
              <option value="Sangat Baik">Sangat Baik</option>
            </select>
          </div>
        </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.app_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dss_project\resources\views/app/wp.blade.php ENDPATH**/ ?>