

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">JADWAL PRAKTEK LAB JURUSAN <?php echo e(strtoupper($jurusan)); ?> SEMESTER <?php echo e(strtoupper($semester->semester)); ?> <?php echo e($semester->ta); ?></h5>

            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Tanggal</th>
                        <th>Kelas</th>
                        <th>Tingkat</th>
                        <th>Ruangan Lab</th>
                        <th>Hari</th>
                        <th>Waktu Mulai</th>
                        <th>Waktu Selesai</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->tgl); ?></td>
                    <td><?php echo e($a->kelas); ?></td>
                    <td><?php echo e($a->tingkat); ?></td>
                    <td><?php echo e($a->ruang); ?></td>
                    <td><?php echo e($a->hari); ?></td>
                    <td><?php echo e(substr($a->waktu_mulai,0,5)); ?></td>
                    <td><?php echo e(substr($a->waktu_selesai,0,5)); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

          </div>
        </div>
      </div>

      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a  href="<?php echo e(url('user/req_jadwal')); ?>" class="btn btn-outline-primary btn-sm"><span><i class="ti ti-plus"></i></span> Formulir Peminjaman Ruang Lab</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">PERMINTAAN PEMINJAMAN RUANG LAB JURUSAN <?php echo e(strtoupper($jurusan)); ?> SEMESTER <?php echo e(strtoupper($semester->semester)); ?> <?php echo e($semester->ta); ?></h5>

            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Nama</th>
                        <th>Kelas</th>
                        <th>Tingkat</th>
                        <th>Ruangan Lab</th>
                        <th>Hari</th>
                        <th>Waktu Mulai</th>
                        <th>Waktu Selesai</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data_req; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->updated_at); ?></td>
                    <td><?php echo e($a->kelas); ?></td>
                    <td><?php echo e($a->tingkat); ?></td>
                    <td><?php echo e($a->ruang); ?></td>
                    <td><?php echo e($a->hari); ?></td>
                    <td><?php echo e(substr($a->waktu_mulai,0,5)); ?></td>
                    <td><?php echo e(substr($a->waktu_selesai,0,5)); ?></td>
                    <td>
                        <?php if($a->status=='Diterima'): ?>
                        <span class="badge bg-success rounded-3 fw-semibold"><?php echo e($a->status); ?></span>
                        <?php elseif($a->status=='Menunggu Konfirmasi'): ?>
                        <span class="badge bg-dark rounded-3 fw-semibold"><?php echo e($a->status); ?></span>
                        <?php else: ?>
                        <span class="badge bg-danger rounded-3 fw-semibold"><?php echo e($a->status); ?></span>
                        <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

          </div>
        </div>
      </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adminlab/polkes/resources/views/user/jadwal_praktikum.blade.php ENDPATH**/ ?>