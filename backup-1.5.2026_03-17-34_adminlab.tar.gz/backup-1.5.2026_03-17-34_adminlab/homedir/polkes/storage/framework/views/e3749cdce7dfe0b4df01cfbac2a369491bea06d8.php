

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Request Peminjaman Peralatan Detail <?php echo e($jurusan); ?></h5>
            <form action="<?php echo e(url('petugas/request_submit')); ?>" method="post" onsubmit="disableSubmitButton()">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="peminjaman_id" value="<?php echo e($id); ?>">
            <table class="table table-bordered" style="width:100%">
                <thead style="background-color:#78faed;">
                    <tr>
                        <th width="30">No</th>
                        <th>Jenis</th>
                        <th>Nama Barang</th>
                        <?php if($jenis=='Bahan BHP'): ?>
                        <th>Tgl Pemakaian</th>
                        <?php else: ?>
                        <th>Tgl Pinjaman</th>
                        <th>Tgl Pengembalian</th>
                        <?php endif; ?>
                        <th>Stok Tersedia</th>
                        <th>Stok Pinjam</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input type="hidden" name="id[]" value="<?php echo e($a->id); ?>">
                  <input type="hidden" name="barang_id[]" value="<?php echo e($a->barang_id); ?>">
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->jenis); ?></td>
                    <td><?php echo e($a->nama); ?></td>
                    <?php if($jenis=='Bahan BHP'): ?>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    <?php else: ?>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    <td><?php echo e($a->tgl_pengembalian); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($a->stok); ?> <?php echo e($a->satuan); ?></td>
                    <td><input type="number" name="stok_pinjam[]" value="<?php echo e($a->stok_pinjam); ?>" class="form-control" required></td>
                    <td>
                      <select id="status" name="status[]" class="form-control" required>
                        <option value=""><?php echo e($a->status); ?></option>
                        <?php if($jenis=='Bahan BHP'): ?>
                        <option value="Pemakaian">Pemakaian</option>
                        <?php else: ?>
                        <option value="Dipinjamkan">Dipinjamkan</option>
                        <?php endif; ?>
                        <option value="Ditolak">Ditolak</option>
                      </select>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div style="float: right;">
              <button class="btn btn-primary btn-sm" type="submit" id="submitButton">Submit</button>
            </div>
            </form>
          </div>
        </div>
      </div>

<script>
    function disableSubmitButton() {
        document.getElementById("submitButton").disabled = true;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/urbx6991/polkes/resources/views/petugas_lab/request_detail.blade.php ENDPATH**/ ?>