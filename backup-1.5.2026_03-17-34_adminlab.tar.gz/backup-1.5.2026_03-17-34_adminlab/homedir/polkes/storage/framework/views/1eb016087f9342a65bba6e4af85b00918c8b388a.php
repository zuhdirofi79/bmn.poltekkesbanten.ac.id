laoran 

https://www.kawankoding.id/belajar-laravel-roles-permission/


admin@kawankoding.id
12345678

user@kawankoding.id
12345678<?php /**PATH C:\xampp\htdocs\Laravel7\resources\views/laporan_pdf.blade.php ENDPATH**/ ?>