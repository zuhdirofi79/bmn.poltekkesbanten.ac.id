

<?php $__env->startSection('content'); ?>
      <div class="container-fluid col-lg-9">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">UPDATE JADWAL PRAKTEK LAB JURUSAN <?php echo e(strtoupper($jurusan)); ?></h5>

            <form action="<?php echo e(url('petugas/edit_jadwal')); ?>" method="post">
              <?php echo csrf_field(); ?>
                <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">

                  <div class="form-group mb-3 row">
                    <label for="penanggung_jawab" class="col-sm-3 col-form-label">Penanggung Jawab/Dosen</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="penanggung_jawab" name="penanggung_jawab" value="<?php echo e($data->penanggung_jawab); ?>" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="kelas" class="col-sm-3 col-form-label">Kelas</label>
                    <div class="col-sm-9">
                      <select id="kelas" name="kelas" class="form-control" required>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($e->matkul==$data->kelas): ?>
                            <option value="<?php echo e($e->matkul); ?>" selected><?php echo e($e->matkul); ?></option>
                          <?php else: ?>
                            <option value="<?php echo e($e->matkul); ?>"><?php echo e($e->matkul); ?></option>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                  
                  <div class="form-group mb-3 row">
                    <label for="tingkat" class="col-sm-3 col-form-label">Tingkat</label>
                    <div class="col-sm-9">
                      <select id="tingkat" name="tingkat" class="form-control" required>
                        <?php $__currentLoopData = $tingkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($d->tingkat==$data->tingkat): ?>
                          <option value="<?php echo e($d->tingkat); ?>" selected><?php echo e($d->tingkat); ?></option>
                          <?php else: ?>
                          <option value="<?php echo e($d->tingkat); ?>"><?php echo e($d->tingkat); ?></option>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>

                 <div class="form-group mb-3 row">
                    <label for="ruang" class="col-sm-3 col-form-label">Ruang</label>
                    <div class="col-sm-9">
                      <select id="ruang" name="ruang" class="form-control" required>
                        <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($b->nama_ruang==$data->ruang): ?>
                          <option value="<?php echo e($b->nama_ruang); ?>" selected><?php echo e($b->kampus); ?> - <?php echo e($b->nama_ruang); ?></option>
                          <?php else: ?>
                          <option value="<?php echo e($b->nama_ruang); ?>"><?php echo e($b->kampus); ?> - <?php echo e($b->nama_ruang); ?></option>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="hari" class="col-sm-3 col-form-label">Hari</label>
                    <div class="col-sm-9">
                      <select id="hari" name="hari" class="form-control" required>
                        <?php $__currentLoopData = $hari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($c->hari==$data->hari): ?>
                          <option value="<?php echo e($c->hari); ?>" selected><?php echo e($c->hari); ?></option>
                          <?php else: ?>
                          <option value="<?php echo e($c->hari); ?>"><?php echo e($c->hari); ?></option>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="waktu_mulai" class="col-sm-3 col-form-label">Waktu Mulai</label>
                    <div class="col-sm-9">
                      <input type="time" class="form-control" id="waktu_mulai" name="waktu_mulai" value="<?php echo e($data->waktu_mulai); ?>" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="waktu_selesai" class="col-sm-3 col-form-label">Waktu Selesai</label>
                    <div class="col-sm-9">
                      <input type="time" class="form-control" id="waktu_selesai" name="waktu_selesai" value="<?php echo e($data->waktu_selesai); ?>" required>
                    </div>
                  </div>

                  <div class="form-group mb-3 row">
                    <label for="tujuan" class="col-sm-3 col-form-label">Tujuan</label>
                    <div class="col-sm-9">
                      <select id="tujuan" name="tujuan" class="form-control" required>
                          <?php $__currentLoopData = $tujuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($f->jutuan==$data->tujuan): ?>
                          <option value="<?php echo e($f->tujuan); ?>" selected><?php echo e($f->tujuan); ?></option>
                          <?php else: ?>
                          <option value="<?php echo e($f->tujuan); ?>"><?php echo e($f->tujuan); ?></option>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>

                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </form>

          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema_select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/detail_jadwal.blade.php ENDPATH**/ ?>