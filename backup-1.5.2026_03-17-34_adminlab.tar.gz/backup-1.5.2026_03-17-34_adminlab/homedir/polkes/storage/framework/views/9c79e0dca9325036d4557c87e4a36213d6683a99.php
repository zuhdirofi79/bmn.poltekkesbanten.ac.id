<?php $__env->startComponent('mail::message'); ?>
# Pemberitahuan Status Peminjaman

Halo <?php echo e($data['nama']); ?>,

Permintaan Peminjaman Anda dengan nomor id <?php echo e($data['id']); ?> telah diterima.

### Detail Peminjaman:
- Nama Barang : <?php echo e($data['nama_barang']); ?>

- Jenis Barang : <?php echo e($data['jenis']); ?>

- Tanggal Peminjaman : <?php echo e($data['tgl_pinjaman']); ?>

- Tanggal Pengembalian : <?php echo e($data['tgl_pengembalian']); ?>


Mohon pastikan Anda mengembalikan barang tersebut sesuai kesepakatan, Jika jenis barang adalah Bahan BHP maka tidak perlu dikembalikan.

Terima kasih.

Salam,
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /home/adminlab/polkes/resources/views/emails/notifikasi.blade.php ENDPATH**/ ?>