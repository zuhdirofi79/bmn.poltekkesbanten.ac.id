
<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
            <h4>PEMILIHAN HARGA DAN KONDISI TANAH TERBAIK MENGGUNAKAN METODE TOPSIS</h4>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Alternatif</h3>
                <div class="float-right">
                  <a href="" class="btn btn-outline-primary" data-toggle="modal" data-target="#exampleModal">+ Tambah data alternatif</a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Code</th>
                    <th>Nama Jalan</th>
                    <th>Lokasi</th>
                    <th>Luas Tanah</th>
                    <th>Harga</th>
                    <th>Ukuran</th>
                    <th>Resiko</th>
                    <th>#</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->code); ?></td>
                    <td><?php echo e($a->nama_jalan); ?></td>
                    <td><?php echo e($a->lokasi); ?></td>
                    <td><?php echo e($a->luas_tanah); ?> M<sup>2</sup></td>
                    <td>Rp. <?php echo e(number_format($a->harga, 0, ",", ".")); ?></td>
                    <td><?php echo e($a->ukuran); ?></td>
                    <td><?php echo e($a->resiko); ?></td>
                    <td>
                      <a href="" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#editModal<?php echo e($loop->iteration); ?>"><i class="nav-icon fas fa-edit"></i></a>
                      <a href="<?php echo e(url('topsis/delete/'.$a->id)); ?>" class="btn btn-outline-danger btn-sm" onclick="(confirm('Anda yakin ingin menghapus data ini?'))"><i class="nav-icon fas fa-trash"></i></a>
                    </td>
                  </tr>

                  <!-- Modal -->
                  <div class="modal fade" id="editModal<?php echo e($loop->iteration); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                        <form action="<?php echo e(url('topsis/update')); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">

                          <div class="form-group row">
                            <label for="code" class="col-sm-3 col-form-label">Code</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="code" name="code" value="<?php echo e($a->code); ?>" required>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="nama_jalan" class="col-sm-3 col-form-label">Nama Jalan</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="nama_jalan" name="nama_jalan" value="<?php echo e($a->nama_jalan); ?>" required>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="lokasi" class="col-sm-3 col-form-label">Keadaan Lokasi</label>
                            <div class="col-sm-9">
                              <select class="form-control" id="lokasi" name="lokasi" required>
                                <option value="Sangat Buruk" <?php echo $a->lokasi == 'Sangat Buruk'? 'selected' : ''; ?> >Sangat Buruk</option>
                                <option value="Buruk" <?php echo $a->lokasi == 'Buruk'? 'selected' : ''; ?>>Buruk</option>
                                <option value="Kurang Baik" <?php echo $a->lokasi == 'Kurang Baik'? 'selected' : ''; ?>>Kurang Baik</option>
                                <option value="Baik" <?php echo $a->lokasi == 'Baik'? 'selected' : ''; ?>>Baik</option>
                                <option value="Sangat Baik" <?php echo $a->lokasi == 'Sangat Baik'? 'selected' : ''; ?>>Sangat Baik</option>
                              </select>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="luas_tanah" class="col-sm-3 col-form-label">Luas Tanah</label>
                            <div class="col-sm-9">
                              <div class="input-group-prepend">
                                <input type="number" class="form-control" id="luas_tanah" name="luas_tanah" value="<?php echo e($a->luas_tanah); ?>" required>
                                <div class="input-group-text">M<sup>2</sup></div>
                              </div>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="harga" class="col-sm-3 col-form-label">Harga / M<sup>2</sup></label>
                            <div class="col-sm-9">
                              <div class="input-group-prepend">
                                <div class="input-group-text">Rp.</div>
                                <input type="number" class="form-control" id="harga" name="harga" value="<?php echo e($a->harga); ?>" required>
                              </div>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="ukuran" class="col-sm-3 col-form-label">Bentuk Ukuran</label>
                            <div class="col-sm-9">
                              <select class="form-control" id="ukuran" name="ukuran" required>
                                <option value="Sangat Buruk" <?php echo $a->ukuran == 'Sangat Buruk'? 'selected' : ''; ?> >Sangat Buruk</option>
                                <option value="Buruk" <?php echo $a->ukuran == 'Buruk'? 'selected' : ''; ?>>Buruk</option>
                                <option value="Kurang Baik" <?php echo $a->ukuran == 'Kurang Baik'? 'selected' : ''; ?>>Kurang Baik</option>
                                <option value="Baik" <?php echo $a->ukuran == 'Baik'? 'selected' : ''; ?>>Baik</option>
                                <option value="Sangat Baik" <?php echo $a->ukuran == 'Sangat Baik'? 'selected' : ''; ?>>Sangat Baik</option>
                              </select>
                            </div>
                          </div>

                          <div class="form-group row">
                            <label for="resiko" class="col-sm-3 col-form-label">Resiko</label>
                            <div class="col-sm-9">
                              <select class="form-control" id="resiko" name="resiko" required>
                                <option value="Sangat Buruk" <?php echo $a->resiko == 'Sangat Buruk'? 'selected' : ''; ?> >Sangat Buruk</option>
                                <option value="Buruk" <?php echo $a->resiko == 'Buruk'? 'selected' : ''; ?>>Buruk</option>
                                <option value="Kurang Baik" <?php echo $a->resiko == 'Kurang Baik'? 'selected' : ''; ?>>Kurang Baik</option>
                                <option value="Baik" <?php echo $a->resiko == 'Baik'? 'selected' : ''; ?>>Baik</option>
                                <option value="Sangat Baik" <?php echo $a->resiko == 'Sangat Baik'? 'selected' : ''; ?>>Sangat Baik</option>
                              </select>
                            </div>
                          </div>
                          
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                        </form>
                      </div>
                    </div>
                  </div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>

            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">

          <div class="col-7">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Kriteria</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Code</th>
                    <th>Kriteria</th>
                    <th>Tipe</th>
                    <th>Bobot</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $bobot = array(); ?>
                  <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $bobot[$loop->iteration] = $a->bobot; ?>
                  <tr>
                    <td><?php echo e($a->code); ?></td>
                    <td><?php echo e($a->kriteria); ?></td>
                    <td><?php echo e($a->tipe); ?></td>
                    <td><?php echo e($a->bobot); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>

          <div class="col-5">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Variabel Kriteria</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Bobot</th>
                    <th>Keterangan Lokasi, Ukuran, Resiko</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $variabel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($a->id); ?></td>
                    <td><?php echo e($a->ket); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->

        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Matriks Perbandingan Alternatif Dan Kriteria</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Code</th>
                    <th>C1 = Lokasi</th>
                    <th>C2 = Luas Tanah (M<sup>2</sup>)</th>
                    <th>C3 = Harga (Rp/M<sup>2</sup>)</th>
                    <th>C4 = Ukuran</th>
                    <th>C5 = Lokasi</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php 
                    $c1 = array(); $sum_c1 = 0;
                    $c2 = array(); $sum_c2 = 0;
                    $c5 = array(); $sum_c3 = 0;
                    $c4 = array(); $sum_c4 = 0;
                    $c5 = array(); $sum_c5 = 0;
                   ?>
                  <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php 
                    $sum_c1+= pow($a->c1,2);
                    $sum_c2+= pow($a->luas_tanah,2);
                    $sum_c3+= pow($a->harga,2);
                    $sum_c4+= pow($a->c4,2);
                    $sum_c5+= pow($a->c5,2);?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->code); ?></td>
                    <td><?php echo e($a->c1); ?></td>
                    <td><?php echo e($a->luas_tanah); ?></td>
                    <td><?php echo e($a->harga); ?></td>
                    <td><?php echo e($a->c4); ?></td>
                    <td><?php echo e($a->c5); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Membuat Matriks Keputusan Ternormalisasi</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Code</th>
                    <th>C1</th>
                    <th>C2</th>
                    <th>C3</th>
                    <th>C4</th>
                    <th>C5</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td></td>
                    <td>Pembagi</td>
                    <td><?php echo e(round(sqrt($sum_c1),5)); ?></td>
                    <td><?php echo e(round(sqrt($sum_c2),5)); ?></td>
                    <td><?php echo e(round(sqrt($sum_c3),5)); ?></td>
                    <td><?php echo e(round(sqrt($sum_c4),5)); ?></td>
                    <td><?php echo e(round(sqrt($sum_c5),5)); ?></td>
                  </tr>
                  <tr>
                    <td colspan="7"></td>
                  </tr>
                  <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php 
                    $m1 = $a->c1/sqrt($sum_c1);
                    $m2 = $a->luas_tanah/sqrt($sum_c2);
                    $m3 = $a->harga/sqrt($sum_c3);
                    $m4 = $a->c4/sqrt($sum_c4);
                    $m5 = $a->c5/sqrt($sum_c5);
                  ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->code); ?></td>
                    <td><?php echo e(round($m1,5)); ?></td>
                    <td><?php echo e(round($m2,5)); ?></td>
                    <td><?php echo e(round($m3,5)); ?></td>
                    <td><?php echo e(round($m4,5)); ?></td>
                    <td><?php echo e(round($m5,5)); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Menghitung Matriks Keputusan Ternormalisasi Dan Terbobot</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Code</th>
                    <th>C1</th>
                    <th>C2</th>
                    <th>C3</th>
                    <th>C4</th>
                    <th>C5</th>
                  </tr>
                  </thead>
                  <tbody>

                  <?php 
                    $ternormalisasi_c1 = array(); 
                    $ternormalisasi_c2 = array(); 
                    $ternormalisasi_c3 = array(); 
                    $ternormalisasi_c4 = array(); 
                    $ternormalisasi_c5 = array(); 
                  ?>

                  <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php 
                    $m1 = $a->c1/sqrt($sum_c1);
                    $m2 = $a->luas_tanah/sqrt($sum_c2);
                    $m3 = $a->harga/sqrt($sum_c3);
                    $m4 = $a->c4/sqrt($sum_c4);
                    $m5 = $a->c5/sqrt($sum_c5);
 
                    $t1 = round($m1*$bobot[1],5);
                    $t2 = round($m2*$bobot[2],5);
                    $t3 = round($m3*$bobot[3],5);
                    $t4 = round($m4*$bobot[4],5);
                    $t5 = round($m5*$bobot[5],5);

                    $ternormalisasi_c1[$loop->iteration] = $t1;
                    $ternormalisasi_c2[$loop->iteration] = $t2;
                    $ternormalisasi_c3[$loop->iteration] = $t3;
                    $ternormalisasi_c4[$loop->iteration] = $t4;
                    $ternormalisasi_c5[$loop->iteration] = $t5;
                  ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->code); ?></td>
                    <td><?php echo e($t1); ?></td>
                    <td><?php echo e($t2); ?></td>
                    <td><?php echo e($t3); ?></td>
                    <td><?php echo e($t4); ?></td>
                    <td><?php echo e($t5); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  <tr>
                    <td colspan="7"></td>
                  </tr>

                  <?php 
                    $max1 = max($ternormalisasi_c1);
                    $max2 = max($ternormalisasi_c2);
                    $max3 = min($ternormalisasi_c3);
                    $max4 = max($ternormalisasi_c4);
                    $max5 = min($ternormalisasi_c5);

                    $min1 = min($ternormalisasi_c1);
                    $min2 = min($ternormalisasi_c2);
                    $min3 = max($ternormalisasi_c3);
                    $min4 = min($ternormalisasi_c4);
                    $min5 = max($ternormalisasi_c5);
                  ?>
                  <tr>
                    <th></th>
                    <th>Solusi Ideal + (MAX)</th>
                    <th><?php echo e($max1); ?></th>
                    <th><?php echo e($max2); ?></th>
                    <th><?php echo e($max3); ?></th>
                    <th><?php echo e($max4); ?></th>
                    <th><?php echo e($max5); ?></th>
                  </tr>
                  <tr>
                    <td colspan="7"></td>
                  </tr>
                  <tr>
                    <th></th>
                    <th>Solusi Ideal - (MIN)</th>
                    <th><?php echo e($min1); ?></th>
                    <th><?php echo e($min2); ?></th>
                    <th><?php echo e($min3); ?></th>
                    <th><?php echo e($min4); ?></th>
                    <th><?php echo e($min5); ?></th>
                  </tr>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Menghitung D+ Dan D- Untuk Setiap Alternatif</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th colspan="3">D+</th>
                    <th colspan="3">D-</th>
                  </tr>
                  <tbody>
                  <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php 
                    $m1 = $a->c1/sqrt($sum_c1);
                    $m2 = $a->luas_tanah/sqrt($sum_c2);
                    $m3 = $a->harga/sqrt($sum_c3);
                    $m4 = $a->c4/sqrt($sum_c4);
                    $m5 = $a->c5/sqrt($sum_c5);
 
                    $t1 = round($m1*$bobot[1],5);
                    $t2 = round($m2*$bobot[2],5);
                    $t3 = round($m3*$bobot[3],5);
                    $t4 = round($m4*$bobot[4],5);
                    $t5 = round($m5*$bobot[5],5);

                    $d_positif = sqrt(pow(($max1-$t1),2)+pow(($max2-$t2),2)+pow(($max3-$t3),2)+pow(($max4-$t4),2)+pow(($max5-$t5),2));
                    $d_negatif = sqrt(pow(($min1-$t1),2)+pow(($min2-$t2),2)+pow(($min3-$t3),2)+pow(($min4-$t4),2)+pow(($min5-$t5),2));
                  ?>

                  <tr>
                    <td><?php echo e($a->code); ?></td>
                    <td>&radic;(<?php echo e($max1); ?>-<?php echo e($t1); ?>)<sup>2</sup>+(<?php echo e($max2); ?>-<?php echo e($t2); ?>)<sup>2</sup>+(<?php echo e($max3); ?>-<?php echo e($t3); ?>)<sup>2</sup>+(<?php echo e($max4); ?>-<?php echo e($t4); ?>)<sup>2</sup>+(<?php echo e($max5); ?>-<?php echo e($t5); ?>)<sup>2</sup></td>
                    <td><?php echo e($d_positif); ?></td>
                    <td><?php echo e($a->code); ?></td>
                    <td>&radic;(<?php echo e($min1); ?>-<?php echo e($t1); ?>)<sup>2</sup>+(<?php echo e($min2); ?>-<?php echo e($t2); ?>)<sup>2</sup>+(<?php echo e($min3); ?>-<?php echo e($t3); ?>)<sup>2</sup>+(<?php echo e($min4); ?>-<?php echo e($t4); ?>)<sup>2</sup>+(<?php echo e($min5); ?>-<?php echo e($t5); ?>)<sup>2</sup></td>
                    <td><?php echo e($d_negatif); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>

        <section class="content">
      <div class="container-fluid">
        <div class="row">

          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Menghitung Hasil Preferensi</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="datatables" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Code</th>
                    <th>Alternatif</th>
                    <th>Rumus</th>
                    <th>Preferensi (V)</th>
                  </tr>
                  <tbody>
                  <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php 
                    $m1 = $a->c1/sqrt($sum_c1);
                    $m2 = $a->luas_tanah/sqrt($sum_c2);
                    $m3 = $a->harga/sqrt($sum_c3);
                    $m4 = $a->c4/sqrt($sum_c4);
                    $m5 = $a->c5/sqrt($sum_c5);
 
                    $t1 = round($m1*$bobot[1],5);
                    $t2 = round($m2*$bobot[2],5);
                    $t3 = round($m3*$bobot[3],5);
                    $t4 = round($m4*$bobot[4],5);
                    $t5 = round($m5*$bobot[5],5);

                    $d_positif = sqrt(pow(($max1-$t1),2)+pow(($max2-$t2),2)+pow(($max3-$t3),2)+pow(($max4-$t4),2)+pow(($max5-$t5),2));
                    $d_negatif = sqrt(pow(($min1-$t1),2)+pow(($min2-$t2),2)+pow(($min3-$t3),2)+pow(($min4-$t4),2)+pow(($min5-$t5),2));
                  ?>

                  <tr>
                    <td><?php echo e($a->code); ?></td>
                    <td><?php echo e($a->nama_jalan); ?></td>
                    <td><?php echo e($d_negatif); ?>/(<?php echo e($d_negatif); ?>+<?php echo e($d_positif); ?>)</td>
                    <td><?php echo e($d_negatif/($d_negatif+$d_positif)); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->

        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>






<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="<?php echo e(url('topsis/insert')); ?>" method="post">
        <?php echo csrf_field(); ?>
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <div class="form-group row">
          <label for="code" class="col-sm-3 col-form-label">Code</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" id="code" name="code" required>
          </div>
        </div>

        <div class="form-group row">
          <label for="nama_jalan" class="col-sm-3 col-form-label">Nama Jalan</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" id="nama_jalan" name="nama_jalan" required>
          </div>
        </div>

        <div class="form-group row">
          <label for="lokasi" class="col-sm-3 col-form-label">Keadaan Lokasi</label>
          <div class="col-sm-9">
            <select class="form-control" id="lokasi" name="lokasi" required>
              <option>-- pilih -- </option>
              <option value="Sangat Buruk">Sangat Buruk</option>
              <option value="Buruk">Buruk</option>
              <option value="Kurang Baik">Kurang Baik</option>
              <option value="Baik">Baik</option>
              <option value="Sangat Baik">Sangat Baik</option>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <label for="luas_tanah" class="col-sm-3 col-form-label">Luas Tanah</label>
          <div class="col-sm-9">
            <div class="input-group-prepend">
              <input type="number" class="form-control" id="luas_tanah" name="luas_tanah" required>
              <div class="input-group-text">M<sup>2</sup></div>
            </div>
          </div>
        </div>

        <div class="form-group row">
          <label for="harga" class="col-sm-3 col-form-label">Harga / M<sup>2</sup></label>
          <div class="col-sm-9">
            <div class="input-group-prepend">
              <div class="input-group-text">Rp.</div>
              <input type="number" class="form-control" id="harga" name="harga" required>
            </div>
          </div>
        </div>

        

        <div class="form-group row">
          <label for="ukuran" class="col-sm-3 col-form-label">Bentuk Ukuran</label>
          <div class="col-sm-9">
            <select class="form-control" id="ukuran" name="ukuran" required>
              <option>-- pilih -- </option>
              <option value="Sangat Buruk">Sangat Buruk</option>
              <option value="Buruk">Buruk</option>
              <option value="Kurang Baik">Kurang Baik</option>
              <option value="Baik">Baik</option>
              <option value="Sangat Baik">Sangat Baik</option>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <label for="resiko" class="col-sm-3 col-form-label">Resiko</label>
          <div class="col-sm-9">
            <select class="form-control" id="resiko" name="resiko" required>
              <option>-- pilih -- </option>
              <option value="Sangat Buruk">Sangat Buruk</option>
              <option value="Buruk">Buruk</option>
              <option value="Kurang Baik">Kurang Baik</option>
              <option value="Baik">Baik</option>
              <option value="Sangat Baik">Sangat Baik</option>
            </select>
          </div>
        </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.app_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dss_project\resources\views/app/topsis.blade.php ENDPATH**/ ?>