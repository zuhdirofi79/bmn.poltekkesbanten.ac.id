

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Request Peminjaman Peralatan <?php echo e($jurusan); ?></h5>
            <table id="myTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="30">No</th>
                        <th>Jenis Alat</th>
                        <th>Ruang Lab</th>
                        <th>Penanggung Jawab</th>
                        <th>Tingkat</th>
                        <th>Tgl Permintaan</th>
                        <th>Status</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($a->jenis); ?></td>
                    <td><?php echo e($a->ruangan); ?></td>
                    <td><?php echo e($a->penanggung_jawab); ?></td>
                    <td><?php echo e($a->tingkat); ?></td>
                    <td><?php echo e($a->tgl_pinjaman); ?></td>
                    <td><?php echo e($a->status); ?></td>
                    <td><a href="<?php echo e(url('petugas/request_detail/'.$a->id)); ?>" target="_blank" class="btn btn-outline-primary btn-sm">Detail</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/request.blade.php ENDPATH**/ ?>