<title>Laporan Barang Masuk Per tanggal <?php echo e(substr($tgl_awal,0,10)); ?> sampai <?php echo e(substr($tgl_akhir,0,10)); ?></title>
<style>
table td, table th  { font-family: Arial, Helvetica, sans-serif;font-size: 12px;text-align:center}
.stylefontCustom { font-family: Arial, Helvetica, sans-serif;}
table {
  border-collapse: collapse;
    width: 100%;
}
table, th, td {
  border: 1px solid #000;
  text-align: left
}
th, td {
  padding : 2px
}

.head  th, .head  td {
  border: 0px ;
  text-align: left
}
</style>


<div style="margin:auto;width:700px">


<div class="stylefontCustom" style="text-align:center;font-size:12px;font-weight:bold" >
    Laporan Barang Masuk<br>
    <?php echo e(substr($tgl_awal,0,10)); ?> sampai <?php echo e(substr($tgl_akhir,0,10)); ?>

</div>
<br>

<table width=100%>
  <tr>
      <th width=5px>No</th>
      <th width=70px>Tanggal</th>
      <th width=70px>Kode Barang</th>
      <th>Nama Barang</th>
      <th width=150px>Supplier</th>
      <th width=50px>Jumlah</th>
      <th width=90px>Petugas</th>
  </tr>
  <?php $__currentLoopData = $laporan_barang_masuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
      <td><?php echo e($loop->iteration); ?>.</td>
      <td><?php echo e(substr($a->updated_at,0,10)); ?></td>
      <td><?php echo e($a->kode_barang); ?></td>
      <td style="text-align:left"> <?php echo e($a->nama_barang); ?></td>
      <td style="text-align:left"> <?php echo e($a->nama_supplier); ?></td>
      <td><?php echo e($a->stok_masuk); ?></td>
      <td><?php echo e($a->petugas); ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


</div>
<?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/print_lap_bm.blade.php ENDPATH**/ ?>