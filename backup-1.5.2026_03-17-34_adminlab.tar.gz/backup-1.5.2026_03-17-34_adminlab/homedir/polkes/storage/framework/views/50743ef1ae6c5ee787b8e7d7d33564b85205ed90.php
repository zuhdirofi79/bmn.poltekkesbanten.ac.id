

<?php $__env->startSection('content'); ?>
      <div class="container-fluid">
        <div class="card">
          <div class="card-body">
            <div style="float: right;">
              <a href="<?php echo e(url('petugas/barang?jurusan='.$jurusan)); ?>" class="btn btn-outline-primary btn-sm">Peralatan Laboratorium</a>&nbsp;
              <a href="<?php echo e(url('petugas/barangmedis?jurusan='.$jurusan)); ?>" class="btn btn-outline-primary btn-sm">Peralatan Medis</a>&nbsp;
              <a href="<?php echo e(url('petugas/barangbhp?jurusan='.$jurusan)); ?>" class="btn btn-primary btn-sm">Bahan BHP</a>
            </div>
            <h5 class="card-title fw-semibold mb-4">BAHAN BHP - JURUSAN <?php echo e(strtoupper($jurusan)); ?></h5><hr>

            <p style="text-align:right">
              <a  href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#ModalAddBahan"><span><i class="ti ti-plus"></i></span> Data Bahan</a>
              <a  href="" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#exampleStok"><span><i class="ti ti-plus"></i></span> Stok Barang</a>
            </p>

            <table id="myTable2" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th width="25">No</th>
                        <th>Nama</th>
                        <th>Kimia</th>
                        <th>Stok</th>
                        <th>tgl Expired</th>
                        <th width="56">Edit</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $bhp_bahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($b->nama); ?></td>
                    <td><?php echo e($b->kimia); ?></td>
                    <td><?php echo e($b->stok); ?></td>
                    <td><?php echo e($b->tgl_expired); ?></td>
                    <td>
                      <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#ModalEditBahan<?php echo e($b->id); ?>"><span><i class="ti ti-edit fs-4"></i></span></button>
                        <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#ModalDeleteBahan<?php echo e($b->id); ?>"><span><i class="ti ti-trash fs-4"></i></span></button>
                    </td>
                  </tr>

                  <!-- Modal edit bhp alat-->
                  <div class="modal fade" id="ModalEditBahan<?php echo e($b->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                      <form action="<?php echo e(url('petugas/edit_bhp_bahan')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
                      <input type="hidden" name="id" value="<?php echo e($b->id); ?>">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Edit Data Bahan</h5>
                          <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                        </div>
                        <div class="modal-body">

                          <div class="form-group mb-3 row">
                            <label for="nama" class="col-sm-3 col-form-label">Nama</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($b->nama); ?>" required>
                            </div>
                          </div>

                          <div class="form-group mb-3 row">
                            <label for="kimia" class="col-sm-3 col-form-label">Kimia</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" id="kimia" name="kimia" value="<?php echo e($b->kimia); ?>" required>
                            </div>
                          </div>

                          <div class="form-group mb-3 row">
                            <label for="tgl_expired" class="col-sm-3 col-form-label">Tgl Expired</label>
                            <div class="col-sm-9">
                              <input type="date" class="form-control" id="tgl_expired" name="tgl_expired" value="<?php echo e($b->tgl_expired); ?>" required>
                            </div>
                          </div>

                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary">Edit</button>
                        </div>
                      </form>
                      </div>
                    </div>
                  </div>

                  <!-- Modal delete bhp bahan-->
                  <div class="modal fade" id="ModalDeleteBahan<?php echo e($b->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                      <form action="<?php echo e(url('petugas/delete_bhp_bahan')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
                      <input type="hidden" name="id" value="<?php echo e($b->id); ?>">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Hapus data BHP bahan</h5>
                          <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
                        </div>
                        <div class="modal-body">

                          <div class="form-group">
                            <label for="keterangan">Kenapa anda ingin menghapus data ini?</label>
                            <textarea class="form-control" id="keterangan" name="delete" required></textarea>
                          </div>

                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-danger">Delete</button>
                        </div>
                      </form>
                      </div>
                    </div>
                  </div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

          </div>
        </div>
      </div>


    <!-- Modal add bhp bahan-->
    <div class="modal fade" id="ModalAddBahan" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('petugas/add_bhp_bahan')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Data BHP Bahan</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="nama" class="col-sm-3 col-form-label">Nama Bahan</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="nama" name="nama" required>
              </div>
            </div>
            
            <div class="form-group mb-3 row">
              <label for="kimia" class="col-sm-3 col-form-label">Kimia</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="kimia" name="kimia">
                <small class="form-text text-muted">Opsional</small>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="stok" class="col-sm-3 col-form-label">Stok Awal</label>
              <div class="col-sm-9">
                <input type="number" class="form-control" id="stok" name="stok" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="tgl_expired" class="col-sm-3 col-form-label">Tgl Expired</label>
              <div class="col-sm-9">
                <input type="date" class="form-control" id="tgl_expired" name="tgl_expired" required>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add</button>
          </div>
        </form>
        </div>
      </div>
    </div>

    <!-- Modal stok barang-->
    <div class="modal fade" id="exampleStok" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(url('petugas/penambahan_stok_barang')); ?>" method="post">
        <?php echo csrf_field(); ?>
          <input type="hidden" name="jurusan" value="<?php echo e($jurusan); ?>">
          <input type="hidden" name="jenis_barang" value="Bahan BHP">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Stok Barang</h5>
            <button type="button" class="close btn btn-dark btn-sm" data-dismiss="modal" aria-label="Close">x</button>
          </div>
          <div class="modal-body">

            <div class="form-group mb-3 row">
              <label for="barang_id" class="col-sm-3 col-form-label">Nama Barang</label>
              <div class="col-sm-9">
                <select id="barang_id" name="barang_id" class="form-control" required>
                    <option>--Pilih--</option>
                  <?php $__currentLoopData = $bhp_bahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($a->id); ?>"><?php echo e($a->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="stok" class="col-sm-3 col-form-label">Stok Penambahan</label>
              <div class="col-sm-9">
                <input type="number" class="form-control" id="stok" name="stok" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="tgl_expired" class="col-sm-3 col-form-label">Tgl Expired</label>
              <div class="col-sm-9">
                <input type="date" class="form-control" id="tgl_expired" name="tgl_expired" required>
              </div>
            </div>

            <div class="form-group mb-3 row">
              <label for="keterangan" class="col-sm-3 col-form-label">Keterangan</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="keterangan" name="keterangan">
                <small>Opsional.</small>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add</button>
          </div>
        </form>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.thema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\polkes\resources\views/petugas_lab/barangbhp.blade.php ENDPATH**/ ?>