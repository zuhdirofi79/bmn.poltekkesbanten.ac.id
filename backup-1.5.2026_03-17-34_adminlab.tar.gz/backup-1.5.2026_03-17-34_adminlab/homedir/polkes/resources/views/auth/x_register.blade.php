<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ENV('APP_NAME')}}</title>
  <link rel="shortcut icon" type="image/png" href="{{asset('img')}}/fav.png" />
  <link rel="stylesheet" href="{{asset('thema')}}/assets/css/styles.min.css" />
</head>

<body>
  <!--  Body Wrapper -->
  <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
    data-sidebar-position="fixed" data-header-position="fixed">
    <div
      class="position-relative overflow-hidden radial-gradient min-vh-100 d-flex align-items-center justify-content-center">
      <div class="d-flex align-items-center justify-content-center w-100">
        <div class="row justify-content-center w-100">
          <div class="col-md-6 col-lg-4 col-xxl-4">
            <div class="card mb-0">
              <div class="card-body">
                <!-- <a href="./index.html" class="text-nowrap logo-img text-center d-block py-3 w-100">
                  <img src="{{asset('img')}}/logo.png" width="120" alt="">
                </a>
                <p class="text-center">{{ENV('APP_NAME')}}</p> -->
                <h4 class="text-center">REGISTRASI</h4>
                <hr>
                <form method="POST" action="{{ route('register') }}">

                  @csrf
                  <div class="mb-3">
                    <label for="name" class="form-label">Nama Lengkap</label>
                    <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" id="name" value="{{ old('name') }}" required autofocus>
                    @error('name')
                    <div id="name" class="form-text text-danger"><strong>{{ $message }}</strong></div>
                    @enderror
                  </div>

                  <div class="mb-3">
                    <label for="role" class="form-label">Akses Sebagai</label>
                    <select id="role" name="role" class="form-control @error('role') is-invalid @enderror">
                      <option>--Pilih--</option>
                      <option value="mahasiswa">Mahasiswa</option>
                      <option value="dosen">Dosen</option>
                    </select>
                    @error('role')
                    <div id="role" class="form-text text-danger"><strong>{{ $message }}</strong></div>
                    @enderror
                  </div>

                  <div class="mb-3">
                    <label for="username" class="form-label">NIM / NID</label>
                    <input type="number" maxlength="10" name="username" class="form-control @error('username') is-invalid @enderror" id="username" value="{{ old('username') }}" required>
                    @error('username')
                    <div id="username" class="form-text text-danger"><strong>{{ $message }}</strong></div>
                    @enderror
                  </div>

                  <div class="mb-3">
                    <label for="email" class="form-label">E-Mail</label>
                    <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" id="email" value="{{ old('email') }}" required>
                    @error('email')
                    <div id="email" class="form-text text-danger"><strong>{{ $message }}</strong></div>
                    @enderror
                  </div>

                  <div class="mb-4">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control @error('password') is-invalid @enderror" id="password" name="password" required >
                    @error('password')
                    <div id="password" class="form-text text-danger"><strong>{{ $message }}</strong></div>
                    @enderror
                  </div>

                  <div class="mb-4">
                    <label for="password_confirmation" class="form-label">Konfirmasi Password</label>
                    <input type="password" class="form-control @error('password_confirmation') is-invalid @enderror" id="password_confirmation" name="password_confirmation" required >
                  </div>

                  <button type="submit" class="btn btn-primary w-100 py-8 fs-4 mb-4 rounded-2">Registrasi</button>

                  <div class="d-flex align-items-center justify-content-center">
                    <p class="fs-4 mb-0 fw-bold">Sudah Memiliki akun?</p>
                    <a class="text-primary fw-bold ms-2" href="{{url('login')}}">Login</a>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="{{asset('thema')}}/assets/libs/jquery/dist/jquery.min.js"></script>
  <script src="{{asset('thema')}}/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>